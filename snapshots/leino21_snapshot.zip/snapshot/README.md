We ended up creating two branches of code as we worked on this submission, and thus we used two separate scripts for training the *GloRo Nets* in our evaluation: `code/training/train_margin_models.py` and `code/training/train_margin_models_clean.py`.
These scripts are roughly functionally equivalent, but we have provided both for better reproducibility.
Here, we include instructions to reproduce our results using these scripts.

We have provided requirements for two environments; we used Tensorflow 1.15 for models trained on MNIST and Tiny-Imagenet, and Tensorflow 2.3 for models trained on CIFAR-10.
To recreate our environments, which we will name `tf1` and `tf2`, with Anaconda, run
```
conda create --name tf1 python=3.7
conda activate tf1
pip install -r requirements_tf1.txt
```
to create `tf1`, or run
```
conda create --name tf2 python=3.7
conda activate tf2
pip install -r requirements_tf2.txt
```
to create `tf2`.

We have provided shell scripts in `code/scripts` that run the appropriate script with the appropriate parameters for each of the models in our evaluation.
The `train_cifar_gloro.sh` and `train_cifar_gloro_t.sh` scripts assume `tf2` is the active environment, and the remaining `*.sh` scripts assume `tf1` is the active environment.

In order to run the `train_tiny-imagenet*.sh` scripts, you must have the Tiny-Imagenet dataset downloaded as a `.npz` file, and you must set the environment variable, `TINY_IMAGENET_PATH`, to point to this file.
Specifically, you should download Tiny-Imagenet, save `x_train`, `y_train`, `x_test`, and `y_test` into a single `.npz` file, and then provide the path to this file in `TINY_IMAGENET_PATH`.
