import os
os.environ['TF_CPP_MIN_LOG_LEVEL'] = '3'

import numpy as np
import tensorflow as tf
import tensorflow.keras.backend as K
import numpy as np

K.set_image_data_format('channels_last')
try:
    # Tensorflow2-specific items.
    from tensorflow.python.framework.ops import disable_eager_execution
    from tensorflow.compat.v1.experimental import output_all_intermediates
    disable_eager_execution()
    output_all_intermediates(True)

    print('disabling eager execution')

    import tensorflow_addons as tfa

except:
    pass

from tensorflow.keras import optimizers
from tensorflow.keras.callbacks import Callback
from tensorflow.keras.callbacks import LearningRateScheduler
from tensorflow.keras.layers import Activation
from tensorflow.keras.layers import Conv2D
from tensorflow.keras.layers import Dense
from tensorflow.keras.layers import Flatten
from tensorflow.keras.layers import Input
from tensorflow.keras.layers import Dropout
from tensorflow.keras.losses import CategoricalCrossentropy
from tensorflow.keras.models import Model
from tensorflow.keras.models import Sequential
from tensorflow.keras.models import load_model
from tensorflow.python.ops.parallel_for.gradients import jacobian
from time import time

from datalib import Cifar10
from datalib import Lfw
from datalib import Mnist
from datalib.processors import Normalize

from cachable import Cachable
from cachable.loaders import TfKerasModelLoader
from scriptify import scriptify

import sys
sys.path.append('..')

from training.lipschitz_margin import add_extra_column
from training.lipschitz_margin_clean import instrument_with_spectral_norm_margin
from training.lipschitz_margin_clean import LipschitzMargin
from training.lipschitz_margin_clean import SpectralNormViaPowerMethod



def string_to_architecture(data, architecture, initialization='glorot_uniform'):

    layers = architecture.split('.')

    flat = len(data.input_shape) == 1

    x = Input(data.input_shape)
    z = x

    for layer_string in layers:
        if layer_string.startswith('('):
            # This is a convolutional layer.
            if flat:
                raise ValueError(
                    'cannot have a convolutional layer on a flat input')

            layer_info = layer_string[1:-1].split(',')
            strides = 1
            padding = 'same'
            if len(layer_info) >= 2:
                channels = int(layer_info[0])
                kernel_size = int(layer_info[1])

            if len(layer_info) >= 3:
                strides = int(layer_info[2])

            if len(layer_info) >= 4:
                padding = layer_info[3]

            z = Conv2D(
                channels,
                kernel_size,
                strides=strides,
                padding=padding,
                activation='linear',
                kernel_initializer=initialization)(z)
            z = Activation('relu')(z)

        elif layer_string.startswith('d'):

            rate = float("0.{}".format(layer_string[1:]))
            z = Dropout(rate)(z)

        else:
            # This is a dense layer.
            if not flat:
                z = Flatten()(z)
                flat = True

            z = Dense(int(layer_string), kernel_initializer=initialization)(z)
            z = Activation('relu')(z)

    if not flat:
        z = Flatten()(z)

    y = Dense(data.num_classes, kernel_initializer=initialization)(z)

    return Model(x, y)


class EpsilonScheduler(Callback):
    def __init__(self, model, epsilon, schedule_string, duration):

        def set_eps(epsilon):
            model.layers[-1].epsilon = epsilon

        self._set_eps = set_eps

        if schedule_string == 'fixed':
            self._epoch_to_eps = [epsilon]

        elif schedule_string == 'linear_half':
            self._epoch_to_eps = [
                epsilon * i / (duration // 2) for i in range(duration // 2 + 1)
            ]

        elif schedule_string == 'linear':
            self._epoch_to_eps = [
                epsilon * i / (duration - 1) for i in range(duration)
            ]

        elif schedule_string == 'logarithmic':
            initial = 0.01
            final = 1.

            self._epoch_to_eps = [
                epsilon * np.log(
                    (np.exp(final) - np.exp(initial)) / (duration - 1) * i +
                    np.exp(initial))
                for i in range(duration)
            ]

        elif schedule_string == 'logarithmic_half':
            initial = 0.01
            final = 1.

            self._epoch_to_eps = [
                epsilon * np.log(
                    (np.exp(final) - np.exp(initial)) / (duration // 2) * i +
                    np.exp(initial))
                for i in range(duration // 2 + 1)
            ]

        else:
            raise ValueError(f'unrecognized schedule string: {schedule_string}')

        print(f'EPSILON SCHEDULE: {np.array(self._epoch_to_eps).round(4)}')

        self.__prev_eps = None
        self.__current_eps = self._epoch_to_eps[0]

    def on_epoch_begin(self, epoch, logs=None):
        if epoch < len(self._epoch_to_eps):
            next_eps = self._epoch_to_eps[epoch]

            self._set_eps(next_eps)
        
            if self.__prev_eps is None or self.__prev_eps != self.__current_eps:
                print(f'---- setting epsilon={next_eps:.3f} ----')

            self.__prev_eps = self.__current_eps
            self.__current_eps = next_eps


class LrScheduler(LearningRateScheduler):

    def __init__(self, schedule_string, duration):
        if schedule_string == 'fixed':
            def scheduler(epoch, lr):
                return lr

        elif schedule_string.startswith('decay_to_'):
            end_lr = float(schedule_string.split('decay_to_')[1].split('_')[0])

            if schedule_string.endswith('_after_half'):
                def scheduler(epoch, lr):
                    if epoch < duration // 2:
                        self._initial_lr = lr

                        return lr

                    else:
                        return self._initial_lr * (self._initial_lr / end_lr)**(
                            -(epoch - duration // 2) / (duration // 2))

            else:
                def scheduler(epoch, lr):
                    if epoch == 0:
                        self._initial_lr = lr

                    return self._initial_lr * (self._initial_lr / end_lr)**(
                        -epoch / duration)

        elif (schedule_string.startswith('half_') and 
                schedule_string.endswith('_times')):

            times = int(schedule_string.split('half_')[1].split('_times')[0])
            period = duration // times

            def scheduler(epoch, lr):
                if epoch % period == period - 1:
                    return lr / 2.
                else:
                    return lr

        else:
            raise ValueError(f'unrecognized schedule string: {schedule_string}')

        super().__init__(scheduler, verbose=1)


class SaveBestWeights(Callback):
    def __init__(
            self, model, test_x, test_y, eval_epsilon=None):

        self._file = f'/tmp/best_weights_{int(np.random.rand() * 1e8)}.h5'

        self._model = model
        self._best_vra = 0.
        self._x = test_x
        self._y = test_y

        self._eval_epsilon = eval_epsilon

    def on_epoch_begin(self, epoch, logs=None):
        if epoch == 0:
            return

        if self._eval_epsilon is not None:
            old_epsilon = self._model.layers[-1].epsilon
            self._model.layers[-1].epsilon = self._eval_epsilon

        _, vra = self._model.evaluate(
            self._x, self._y, batch_size=256, verbose=0)

        print(
            f'\nVRA at epsilon={self._model.layers[-1].epsilon:.3f}: {vra:.4f}')

        if vra >= self._best_vra:
            print('  saving new best weights...')
            self._model.save_weights(self.weight_file)

            self._best_vra = vra

        if self._eval_epsilon is not None:
            self._model.layers[-1].epsilon = old_epsilon

        print('')

    @property
    def weight_file(self):
        return self._file


class UpdatePowerIterates(Callback):
    def __init__(self, model, duration, convergence_threshold=1e-4):
        self._duration = duration
        self._convergence_threshold = convergence_threshold

        spectral_norm_layer = model.get_layer('spectral_norm')
        self._spectral_norm_layer = spectral_norm_layer
        self._converge_iterates = spectral_norm_layer.refresh_iterates
        self._update_iterates = spectral_norm_layer.update_iterates


    def on_epoch_begin(self, epoch, logs=None):
        print('\n-- refreshing iterates --')
        self._converge_iterates(
            convergence_threshold=self._convergence_threshold,
            max_tries=1000,
            batch_size=100)
        print(f'  K = {self._spectral_norm_layer._lipschitz_constant}')

    def on_epoch_end(self, epoch, logs=None):
        if epoch >= self._duration - 1:
            print('\n-- refreshing iterates --')
            self._converge_iterates(
                convergence_threshold=self._convergence_threshold,
                max_tries=1000,
                batch_size=100)
            print('-')

    def on_train_batch_end(self, batch, logs=None):
        self._update_iterates()


class ImageDataPipeline(object):
    def __init__(self, data):

        is_tf2 = tf.__version__.startswith('2')

        x = Input(data.input_shape)

        self._x = x

        # Randomly flip.
        if not data.__class__.__name__ == 'Mnist':
            x = tf.image.random_flip_left_right(x)

        # Randomly adjust the saturation and contrast.
        if data.input_shape[-1] == 3:
            x = tf.image.random_saturation(x, lower=0.5, upper=1.2)

        x = tf.image.random_contrast(x, lower=0.8, upper=1.2)

        # Ranodm rotation.
        batch_size = tf.shape(x)[0]
        
        if is_tf2:
            # Rotations only work in tf2.
            x = tfa.image.rotate(
                x, tf.random.uniform([batch_size], -0.157, 0.157))

        # Randomly zoom.
        widths = tf.random.uniform([batch_size], 0.8, 1.)
        top_corners = tf.random.uniform([batch_size, 2], 0, 1. - widths[:,None])
        bottom_corners = top_corners + widths[:,None]
        boxes = tf.concat((top_corners, bottom_corners), axis=1)

        if is_tf2:
            x = tf.image.crop_and_resize(
                x, boxes, 
                box_indices=tf.range(batch_size), 
                crop_size=data.input_shape[0:2])

        else:
            x = tf.image.crop_and_resize(
                x, boxes, 
                box_ind=tf.range(batch_size), 
                crop_size=data.input_shape[0:2])

        # Randomly add low-magnitude noise?
        x = x + tf.random.normal(tf.shape(x), stddev=0.01)

        self._pipeline = x

    def __call__(self, model):
        print('adding data pipeline...')

        return Model(self._x, model(self._pipeline))


def MarginTradesLoss(lam=1.):
    crossentropy = CategoricalCrossentropy(from_logits=True)

    def trades_loss(y_true, y_pred):
        # Encourage predicting the correct class, even non-robustly.
        standard_loss = crossentropy(y_true[:, :-1], y_pred[:, :-1])

        # Encourage predicting robustly, even incorrectly. We take the robust
        # loss but using the model's prediction as the ground truth.
        new_ground_truth = tf.concat(
            (K.softmax(y_pred[:, :-1]), tf.zeros((tf.shape(y_true)[0], 1))),
            axis=1)

        robust_loss = crossentropy(new_ground_truth, y_pred)

        return standard_loss + lam * robust_loss

    return trades_loss


def LocalLipschitzLoss(model=None, gamma=0.5):
    crossentropy = CategoricalCrossentropy(from_logits=True)

    if model is not None:
        x = model.input

        # Special case for if we're using our data augmentation pipeline.
        if model.layers[-1].__class__.__name__ == 'Functional':
            x = model.layers[-2].output
            model = model.layers[-1]

    def localness_loss(y_true, y_pred):
        robust_loss = crossentropy(y_true, y_pred)

        # This is only for when loading the model, in which case the loss
        # doesn't matter.
        if model is None:
            return robust_loss

        L = tf.linalg.norm(model.layers[-2].lipschitz_constant, axis=0)[None]

        print(model.layers[-3]._inbound_nodes[0].outputs)
        print(model.layers[-3]._inbound_nodes[1].outputs)

        y = model.layers[-3]._inbound_nodes[1].outputs

        j = jacobian(
            K.sum(model.layers[-3]._inbound_nodes[1].outputs, axis=0), x)

        g = tf.transpose(
            K.reshape(
                jacobian(K.sum(y, axis=0), x),
                (10,-1,np.prod(model.input_shape[1:]))),
            (1, 2, 0))

        norm_g = tf.linalg.norm(g, axis=1)

        return robust_loss + gamma * K.mean(((L - norm_g) / L)**2)

    return localness_loss


class CacheLoader(TfKerasModelLoader):

        def __init__(self):
            super().__init__(custom_objects={
                'LipschitzMargin': LipschitzMargin,
                'SpectralNormViaPowerMethod': SpectralNormViaPowerMethod,
                'trades_loss': MarginTradesLoss(),
                'localness_loss': LocalLipschitzLoss(),
            })

        def load(self, filename):
            model_best = super().load(filename + '.best')
            model_final = super().load(filename + '.final')
            return model_best, model_final

        def save(self, filename, models):
            model_best, model_final = models

            model_best.save(filename + '.best.h5')
            model_final.save(filename + '.final.h5')


@Cachable('margin_model_clean', directory='models', loader=CacheLoader())
def train_margin_model(
        data,
        architecture,
        epsilon,
        norm='l2',
        lipschitz_bound='spectral_pow',
        training_strategy='standard',
        loss='standard',
        optimizer='adam',
        learning_rate=1e-4,
        learning_rate_schedule='fixed',
        epsilon_schedule='fixed',
        epochs=200,
        batch_size=128,
        overcompensate_eps=1.,
        use_data_augmentation=False,
        warmup_epochs=0,
        initialization='glorot_uniform',
        kernel_regularization=None):

    f = string_to_architecture(data, architecture, initialization)

    x = f.input
    y = f.output

    callbacks = []

    y_tr_extra_column = add_extra_column(data.y_tr_1hot)
    y_te_extra_column = add_extra_column(data.y_te_1hot)

    # Create the model.
    if lipschitz_bound.startswith('spectral_pow'):
        split = lipschitz_bound.split('spectral_pow.')

        num_iterations = int(split[1]) if len(split) == 2 else 5

        model = instrument_with_spectral_norm_margin(
            f, epsilon, num_iterations, norm, maintain_state=True)

        spectral_norm_layer = model.get_layer('spectral_norm')

        callbacks.append(UpdatePowerIterates(model, epochs))
        save_best_callback = SaveBestWeights(
            model, data.x_te, y_te_extra_column, eval_epsilon=epsilon)

    else:
        raise ValueError(f'Unknown Lipschitz bound strategy: {lipschitz_bound}')

    model_to_train = (
        ImageDataPipeline(data)(model) if use_data_augmentation else model)

    callbacks.append(save_best_callback)
    callbacks.append(LrScheduler(learning_rate_schedule, epochs))
    callbacks.append(EpsilonScheduler(
        model, epsilon * overcompensate_eps, epsilon_schedule, epochs))

    model.summary()

    optimizer_params = {'learning_rate': learning_rate}

    if loss == 'standard':
        loss_function = CategoricalCrossentropy(from_logits=True)

    elif loss.startswith('trades'):
        split = loss.split('trades.')

        lam = float(split[1]) if len(split) == 2 else 1.

        loss_function = MarginTradesLoss(lam)

    elif loss.startswith('local'):
        loss_function = LocalLipschitzLoss(model_to_train)

    else:
        raise ValueError(f'Unknown loss function: {loss}')

    if warmup_epochs > 0:
        f_tr = ImageDataPipeline(data)(f) if use_data_augmentation else f
        f_tr.compile(
            loss=CategoricalCrossentropy(from_logits=True),
            optimizer=optimizers.get(optimizer).__class__(**optimizer_params),
            metrics=['acc'])

        print('warming up...')
        f_tr.fit(
            data.x_tr,
            data.y_tr_1hot,
            epochs=warmup_epochs,
            batch_size=batch_size,
            validation_data=(data.x_te, data.y_te_1hot))

    model_to_train.compile(
        loss=loss_function,
        optimizer=optimizers.get(optimizer).__class__(**optimizer_params),
        metrics=['acc'])
    model.compile(
        loss=CategoricalCrossentropy(from_logits=True),
        optimizer=optimizers.get(optimizer).__class__(**optimizer_params),
        metrics=['acc'])

    model_to_train.fit(
        data.x_tr,
        y_tr_extra_column,
        epochs=epochs,
        batch_size=batch_size,
        callbacks=callbacks)

    # Return the model's epsilon to the original desired epsilon in case it was
    # set to something else during training.
    model.layers[-1].epsilon = epsilon

    # Reload the model with the best weights during training.
    if epochs > 0:
        tmp_file = f'/tmp/model_reload_{int(np.random.rand() * 1e8)}.h5'
        model.save(tmp_file)
        best_model = load_model(tmp_file, custom_objects={
            'LipschitzMargin': LipschitzMargin,
            'SpectralNormViaPowerMethod': SpectralNormViaPowerMethod,
            'trades_loss': MarginTradesLoss(),
            'localness_loss': LocalLipschitzLoss(),
        })
        best_model.load_weights(save_best_callback.weight_file)

    else:
        best_model = model

    return best_model, model


if __name__ == '__main__':

    @scriptify
    def script(
            dataset,
            architecture,
            epsilon,
            norm='l2',
            lipschitz_bound='spectral_pow',
            training_strategy='standard',
            loss='standard',
            optimizer='adam',
            learning_rate=1e-4,
            learning_rate_schedule='fixed',
            epsilon_schedule='fixed',
            epochs=200,
            batch_size=128,
            alternate_rate=5,
            normalization='normalize',
            overcompensate_eps=1.,
            use_data_augmentation=False,
            warmup_epochs=0,
            initialization='glorot_uniform',
            kernel_regularization=None,
            gpu=0):

        print('configuring gpu...')
        # Select the GPU and allow memory growth to avoid taking all the RAM.
        gpus = tf.config.experimental.list_physical_devices('GPU')
        tf.config.experimental.set_visible_devices(gpus[gpu], 'GPU')
        device = gpus[gpu]

        for device in tf.config.experimental.get_visible_devices('GPU'):
            tf.config.experimental.set_memory_growth(device, True)

        print('getting dataset...')

        # Make sure architecture is actually a string (scriptify might have
        # inferred a different type).
        if not isinstance(architecture, str):
            architecture = str(architecture)
        if architecture.startswith('<') and architecture.endswith('>'):
            architecture = architecture[1:-1]

        if dataset == 'mnist':
            data = (
                Mnist(processors=[Normalize(-1, 1)])
                    if normalization == 'normalize_-11' else 
                Mnist())

        elif dataset == 'cifar':
            data = (
                Cifar10(processors=[Normalize(-1, 1)])
                    if normalization == 'normalize_-11' else 
                Cifar10())

        elif dataset == 'lfw':
            data = (
                Lfw(
                    processors=[Normalize(-1, 1)],
                    min_faces_per_person=50,
                    color=True) if normalization == 'normalize_-11' else
                Lfw(min_faces_per_person=50, color=True))

        else:
            raise ValueError(f'unknown dataset; {dataset}')

        # For consistency, our epsilons are always reported assuming data that
        # has been scaled to the range [0, 1]. If we scaled the data in any
        # other way, we must scale epsilon accordingly.
        if normalization == 'normalize_-11':
            epsilon = 2 * epsilon

        print('.' * 80)
        print('training model')
        print('.' * 80)

        start_time = time()

        cached_object = train_margin_model(
            data,
            architecture,
            epsilon,
            norm=norm,
            lipschitz_bound=lipschitz_bound,
            training_strategy=training_strategy,
            loss=loss,
            optimizer=optimizer,
            learning_rate=learning_rate,
            learning_rate_schedule=learning_rate_schedule,
            epsilon_schedule=epsilon_schedule,
            epochs=epochs,
            batch_size=batch_size,
            overcompensate_eps=overcompensate_eps,
            use_data_augmentation=use_data_augmentation,
            warmup_epochs=warmup_epochs,
            initialization=initialization,
            kernel_regularization=kernel_regularization)

        end_time = time()

        total_time = end_time - start_time
        time_per_epoch = total_time / max(epochs, 1)

        print(f'\n>> done in {total_time} seconds\n')

        best_model, model = cached_object.obj

        best_model_file = cached_object._filename + '.best.h5'
        final_model_file = cached_object._filename + '.final.h5'

        print('.' * 80)
        print('calculating accuracy')
        print('.' * 80)

        vra = (model.predict(data.x_te).argmax(axis=1) == data.y_te).mean()
        vra_train = (model.predict(
            data.x_tr).argmax(axis=1) == data.y_tr).mean()
        clean_acc = (model.predict(
            data.x_te)[:, :-1].argmax(axis=1) == data.y_te).mean()
        clean_acc_train = (model.predict(
            data.x_tr)[:, :-1].argmax(axis=1) == data.y_tr).mean()

        print(f'VRA:        {vra*100:.1f}%')
        print(f'Clean Acc.: {clean_acc*100:.1f}%')
        print(f'\nTime per epoch: {time_per_epoch:.2f}s')

        best_vra = (
            best_model.predict(data.x_te).argmax(axis=1) == data.y_te).mean()
        best_clean_acc = (best_model.predict(
            data.x_te)[:, :-1].argmax(axis=1) == data.y_te).mean()

        print(f'Best VRA:        {best_vra*100:.1f}%')
        print(f'Best Clean Acc.: {best_clean_acc*100:.1f}%')

        return {
            'vra': vra,
            'clean_acc': clean_acc,
            'vra_train': vra_train,
            'clean_acc_train': clean_acc_train,
            'time_per_epoch': time_per_epoch,
            'best_vra': best_vra,
            'best_clean_acc': best_clean_acc,
            'final_model_file': final_model_file,
            'best_model_file': best_model_file
        }
