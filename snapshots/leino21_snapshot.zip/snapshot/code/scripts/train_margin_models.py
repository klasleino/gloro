import os
import tempfile
os.environ['TF_CPP_MIN_LOG_LEVEL'] = '3'

import numpy as np
import tensorflow as tf
import tensorflow.keras.backend as K

K.set_image_data_format('channels_last')

from tensorflow.keras import optimizers
from tensorflow.keras.layers import Activation
from tensorflow.keras.layers import Conv2D
from tensorflow.keras.layers import Dense
from tensorflow.keras.layers import Flatten
from tensorflow.keras.layers import Input
from tensorflow.keras.layers import Dropout
from tensorflow.keras.losses import CategoricalCrossentropy
from tensorflow.keras.models import Model
from time import time
from tensorflow.keras.utils import Progbar

tf.autograph.set_verbosity(1)
tf.get_logger().setLevel('ERROR')

from datalib import Cifar10
from datalib import Lfw
from datalib import Mnist
from datalib import FashionMnist
from datalib.processors import Normalize, UnitBall
try:
    from datalib import TinyImagenet
except:
    print('no tiny imagenet dataset found')

from cachable import Cachable
from cachable.loaders import TfKerasModelLoader
from scriptify import scriptify

import sys
sys.path.append('..')

from training.lipschitz_margin import add_extra_column
from training.lipschitz_margin import fl, fastlip
from training.lipschitz_margin import FlMargin
from training.lipschitz_margin import global_lipschitz_bound_spectral
from training.lipschitz_margin import SpectralMargin
from training.lipschitz_margin import global_lipschitz_bound
from training.lipschitz_margin import LipschitzMargin
from training.lipschitz_margin import global_lipschitz_bound_linf
from training.lipschitz_margin import global_lipschitz_bound_spectral_power
from training.lipschitz_margin import SpectralStateUpdate
from training.lipschitz_margin import PowerMethodRegularizer
from training.lipschitz_margin import ConstantSpectralMargin
from training.lipschitz_margin import MarginTradesLoss
from training.lipschitz_margin import ResnetBlock_NBN

try:
    # Tensorflow2-specific items.
    from tensorflow.python.framework.ops import disable_eager_execution
    from tensorflow.compat.v1.experimental import output_all_intermediates
    disable_eager_execution()
    output_all_intermediates(True)

    print('disabling eager execution')

    import tensorflow_addons as tfa

except:
    pass

DEFAULT_LOWERBOUND = 1e-16

class TimingCallback(tf.keras.callbacks.Callback):

    def __init__(self):
        self.times = []
        self.first_epoch = True

    def on_epoch_begin(self, epoch, logs={}):
        self.starttime=time()
    
    def on_epoch_end(self, epoch, logs={}):
        ctime = time()-self.starttime
        # throw away the first epoch, which takes extra time to compile
        if not self.first_epoch:
            self.times += [ctime]
        else:
            self.first_epoch = False
        print(f'Epoch took {ctime} seconds')
        with tf.device('/gpu:0'):
            maxmem = tf.keras.backend.get_session().run(tf.contrib.memory_stats.MaxBytesInUse())
        print(f'Current memory usage: {maxmem}\n')
    
    def on_train_end(self, logs=None):
        print(f'\nAverage time per epoch: {np.array(self.times).mean()}\n')

def HalfLrScheduler(**kwargs):
    return ScaledLrScheduler(scaled_by=0.5, **kwargs)

class ContinuousExponentialLrScheduler(tf.keras.callbacks.LearningRateScheduler):
    def __init__(self, schedule_string, duration):
        if schedule_string == 'fixed':
            def scheduler(epoch, lr):
                return lr
        elif schedule_string.startswith('decay_to_'):
            end_lr = float(schedule_string.split('decay_to_')[1].split('_')[0])
            if schedule_string.endswith('_after_half'):
                def scheduler(epoch, lr):
                    if epoch < duration // 2:
                        self._initial_lr = lr
                        return lr
                    else:
                        return self._initial_lr * (self._initial_lr / end_lr)**(
                            -(epoch - duration // 2) / (duration // 2))
            else:
                def scheduler(epoch, lr):
                    if epoch == 0:
                        self._initial_lr = lr
                    return self._initial_lr * (self._initial_lr / end_lr)**(
                        -epoch / duration)
        elif (schedule_string.startswith('half_') and 
                schedule_string.endswith('_times')):
            times = int(schedule_string.split('half_')[1].split('_times')[0])
            period = duration // times
            def scheduler(epoch, lr):
                if epoch % period == period - 1:
                    return lr / 2.
                else:
                    return lr
        else:
            raise ValueError(f'unrecognized schedule string: {schedule_string}')
        super().__init__(scheduler, verbose=1)

def ScaledLrScheduler(initial_lr=1e-3,
                    scaled_by=0.1,
                    start_decay_epoch=0,
                    total_epochs=200,
                    decay_stages=5,
                    smallest_lr=1e-5):

    if initial_lr < smallest_lr:
        raise ValueError(
            "smallest_lr is not smaller than initial learning rate")

    stages = np.array([
        int((total_epochs - start_decay_epoch) * i / decay_stages +
            start_decay_epoch) for i in range(1, decay_stages)
    ])

    def scheduler(epoch, lr):
        if epoch < start_decay_epoch:
            return initial_lr
        else:
            new_lr = max(
                np.power(scaled_by, np.sum(stages < epoch)) * initial_lr,
                smallest_lr)
            print(f'---- decaying learning rate to {new_lr}')
            return new_lr

    return tf.keras.callbacks.LearningRateScheduler(scheduler)

def LinearLrScheduler(initial_lr=1.e-3,
                      start_decay_epoch=0,
                      total_epochs=200,
                      smallest_lr=1.e-5):

    if initial_lr < smallest_lr:
        raise ValueError(
            "smallest_lr is not smaller than initial learning rate")

    rates = np.linspace(initial_lr, smallest_lr,
                        total_epochs - start_decay_epoch)

    def scheduler(epoch, lr):
        if epoch < start_decay_epoch:
            return initial_lr
        else:
            new_lr = rates[epoch - start_decay_epoch]
            print(f'---- decaying learning rate to {new_lr}')
            return new_lr

    return tf.keras.callbacks.LearningRateScheduler(scheduler)

class DelayedCheckpoint(tf.keras.callbacks.Callback):
    def __init__(self, model, filename, start_at_epoch=0):
        self._model = model
        self._epoch = start_at_epoch
        self._file = filename
        self._val_acc = -np.infty
    
    def on_epoch_end(self, epoch, logs=None):
        if self._epoch <= epoch and not (logs is None):
            if logs['val_acc'] >= self._val_acc:
                self._val_acc = logs['val_acc']
                self._model.save_weights(self._file)

class EvalEpsilonCallback(tf.keras.callbacks.Callback):
    def __init__(self, model, eval_epsilon, start_at_epoch=0):
        self._model = model
        self._eval_epsilon = eval_epsilon
        self._start_epoch = start_at_epoch
        self._last_epsilon = None
        self._do_change = False

    def on_epoch_begin(self, epoch, logs=None):
        if self._start_epoch <= epoch:
            self._do_change = True

    def on_test_begin(self, logs=None):
        if self._do_change:
            self._last_epsilon = self._model.layers[-1].epsilon
            self._model.layers[-1].epsilon = self._eval_epsilon

    def on_test_end(self, logs=None):
        if self._do_change:
            self._model.layers[-1].epsilon = self._last_epsilon


class EpsilonScheduler(tf.keras.callbacks.Callback):
    def __init__(self, model, initial_epsilon, final_epsilon, final_epoch):
        self._model = model
        self._init_epsilon = initial_epsilon
        self._epsilon = final_epsilon
        self._epoch = final_epoch

        self._stages = np.linspace(initial_epsilon, final_epsilon,
                                   int(final_epoch))

    def on_epoch_begin(self, epoch, logs=None):
        if epoch < self._epoch:
            cur_epsilon = self._stages[epoch]
            print(f'---- setting epsilon={cur_epsilon}')
        else:
            cur_epsilon = self._epsilon
        self._model.layers[-1].epsilon = cur_epsilon


class TradesScheduler(tf.keras.callbacks.Callback):
    def __init__(self, lam, initial_param, final_param, final_epoch):
        self._lambda = lam
        self._init_param = initial_param
        self._param = final_param
        self._epoch = final_epoch

        self._stages = np.linspace(initial_param, final_param,
                                   int(final_epoch))

    def on_epoch_begin(self, epoch, logs=None):
        if epoch < self._epoch:
            cur_param = self._stages[epoch]
            print(f'---- setting lambda={cur_param}')
        else:
            cur_param = self._param
        tf.keras.backend.set_value(self._lambda, cur_param)


class DataPipeline(object):
    def __init__(self, op_str):
        self.r = 20
        self.w = 0.2
        self.h = 0.2
        self.f = True
        self.s = 0.1
        self.z = 0.1

        if op_str == 'default':
            pass
        else:
            if ',' in op_str:
                op_list = op_str.split(",")
            else:
                op_list = [op_str]

            for op in op_list:
                if hasattr(self, op[0]):
                    setattr(self, op[0], float(op[1:]))
                else:
                    print(
                        f"{op[0]} is not applied since it is not a valid data augmentataion method"
                    )

            if not isinstance(self.f, bool):
                if self.f > 0:
                    self.f = True
                else:
                    self.f = False

    def __call__(self, X):
        data_generator = tf.keras.preprocessing.image.ImageDataGenerator(
            rotation_range=self.r,
            width_shift_range=self.w,
            height_shift_range=self.h,
            horizontal_flip=self.f,
            shear_range=self.s,
            zoom_range=self.z)
        data_generator.fit(X)
        return data_generator


class ImageDataPipeline(object):
    def __init__(self, data):
        self.is_tf2 = tf.__version__.startswith('2')
        self.data = data

    def __call__(self, x):
        # Randomly flip.
        if not self.data.__class__.__name__ == 'Mnist':
            x = tf.image.random_flip_left_right(x)

        # Randomly adjust the saturation and contrast.
        if self.data.input_shape[-1] == 3:
            x = tf.image.random_saturation(x, lower=0.5, upper=1.2)

        x = tf.image.random_contrast(x, lower=0.8, upper=1.2)

        # Ranodm rotation.
        batch_size = tf.shape(x)[0]

        if self.is_tf2:
            # Rotations only work in tf2.
            x = tfa.image.rotate(
                x, tf.random.uniform([batch_size], -0.157, 0.157), name='rotation')

        # Randomly zoom.
        widths = tf.random.uniform([batch_size], 0.8, 1.)
        top_corners = tf.random.uniform([batch_size, 2], 0,
                                        1. - widths[:, None])
        bottom_corners = top_corners + widths[:, None]
        boxes = tf.concat((top_corners, bottom_corners), axis=1)

        if self.is_tf2:
            x = tf.image.crop_and_resize(x,
                                         boxes,
                                         box_indices=tf.range(batch_size),
                                         crop_size=self.data.input_shape[0:2], name='crop_and_resize')

        else:
            x = tf.image.crop_and_resize(x,
                                         boxes,
                                         box_ind=tf.range(batch_size),
                                         crop_size=self.data.input_shape[0:2], name='crop_and_resize')

        # Randomly add low-magnitude noise?
        x = x + tf.random.normal(tf.shape(x), stddev=0.01, name='noise')
        return x


class DataSequence(tf.keras.utils.Sequence):
    def __init__(self, x_set, y_set, batch_size):
        self.x, self.y = x_set, y_set
        self.batch_size = batch_size

    def __len__(self):
        n = len(self.x) // self.batch_size
        if len(self.x) % self.batch_size != 0:
            n += 1
        return n

    def __getitem__(self, idx):
        batch_x = self.x[idx * self.batch_size:(idx + 1) * self.batch_size]
        batch_y = self.y[idx * self.batch_size:(idx + 1) * self.batch_size]
        return batch_x, batch_y


def train_network(m,
                  x,
                  y,
                  data_generator=None,
                  data_preprocesser=None,
                  batch_size=32,
                  epochs=100,
                  validation_data=None,
                  callbacks=None,
                  workers=10,
                  use_multiprocessing=True,
                  do_precise_timing=False):
    if data_preprocesser is not None and data_generator is not None:
        print("data_preprocesser is priorited over data_generator")
    
    if do_precise_timing:
        callbacks += [TimingCallback()]

    if data_generator is None:
        print(":::::::: Training with original data or preprocessing layer ::::::::")
        m.fit(x,
              y,
              batch_size=batch_size,
              epochs=epochs,
              validation_data=validation_data,
              callbacks=callbacks)
    else:
        print(":::::::: Training with data generator ::::::::")
        use_multiprocessing = True if workers > 1 else False

        steps_per_epoch = x.shape[0] // batch_size
        if x.shape[0] % batch_size != 0:
            steps_per_epoch += 1
        m.fit(data_generator.flow(
            x,
            y,
            batch_size=batch_size,
        ),
              steps_per_epoch=steps_per_epoch,
              epochs=epochs,
              validation_data=DataSequence(validation_data[0],
                                           validation_data[1], batch_size),
              callbacks=callbacks,
              use_multiprocessing=use_multiprocessing,
              max_queue_size=1000,
              workers=workers)

    return m


def string_to_architecture(data, architecture, preprocess_layer=None, use_power_reg=False, use_ortho_init=False):

    if '.' in architecture:
        layers = architecture.split('.')
    else:
        layers = [str(architecture)]

    layers = architecture.split('.')

    flat = len(data.input_shape) == 1

    x = Input(data.input_shape)
    
    if preprocess_layer is not None:
        z = preprocess_layer(x)
    else:
        z = x

    res_id = 0
    for layer_string in layers:
        if layer_string.startswith('('):
            # This is a convolutional layer.
            if flat:
                raise ValueError(
                    'cannot have a convolutional layer on a flat input')

            init = None if not use_ortho_init else tf.keras.initializers.Orthogonal()
            layer_info = layer_string[1:-1].split(',')
            strides = 1
            padding = 'same'
            if len(layer_info) >= 2:
                channels = int(layer_info[0])
                kernel_size = int(layer_info[1])

            if len(layer_info) >= 3:
                strides = int(layer_info[2])

            if len(layer_info) >= 4:
                padding = layer_info[3]

            if not use_power_reg:
                next_layer = Conv2D(channels,
                                    kernel_size,
                                    strides=strides,
                                    padding=padding,
                                    kernel_initializer=init,
                                    activation='linear')
                z = next_layer(z)
            else:
                power_reg = PowerMethodRegularizer(strength=1,
                                                   shape=K.int_shape(z)[1:],
                                                   padding=padding,
                                                   strides=strides)
                z = Conv2D(channels,
                           kernel_size,
                           strides=strides,
                           padding=padding,
                           activation='linear',
                           kernel_initializer=init,
                           kernel_regularizer=power_reg)(z)
            z = Activation('relu')(z)

        elif layer_string.startswith('d'):

            rate = float("0.{}".format(layer_string[1:]))
            z = Dropout(rate)(z)

        elif layer_string.startswith('r('):
            # This is a residual block (without BN)

            layer_info = layer_string[2:-1].split(',')
            if len(layer_info) == 2:
                kernel_size = int(layer_info[0])
                filters = [int(layer_info[0])] * 3
            elif len(layer_info) == 4:
                kernel_size = int(layer_info[0])
                filters = [int(layer_info[i]) for i in range(1, 4)]
            else:
                raise ValueError(
                    "Layer infor for residual block (without BN) is not understood"
                )
            z = ResnetBlock_NBN(z,
                                kernel_size,
                                filters,
                                res_id,
                                use_power_reg=use_power_reg,
                                input_shape=K.int_shape(z)[1:])
            res_id += 1
        else:
            # This is a dense layer.
            if not flat:
                z = Flatten()(z)
                flat = True

            init = None if not use_ortho_init else tf.keras.initializers.Orthogonal()
            if not use_power_reg:
                z = Dense(int(layer_string), kernel_initializer=init)(z)
            else:
                power_reg = PowerMethodRegularizer(strength=1)
                z = Dense(int(layer_string), kernel_regularizer=power_reg, kernel_initializer=init)(z)
            z = Activation('relu')(z)

    if not flat:
        z = Flatten()(z)

    y = Dense(data.num_classes)(z)

    return Model(x, y)


@Cachable('margin_model',
          debug=True,
          loader=TfKerasModelLoader(
              custom_objects={
                  'LipschitzMargin': LipschitzMargin,
                  'SpectralMargin': SpectralMargin,
                  'ConstantSpectralMargin': ConstantSpectralMargin
              }),
          directory='models')
def train_margin_model(data,
                       architecture,
                       epsilon,
                       norm='l2',
                       lipschitz_bound='global',
                       loss='crossentropy',
                       training_strategy='alternate_half',
                       optimizer='adam',
                       learning_rate=1e-4,
                       epochs=200,
                       batch_size=128,
                       alternate_rate=1,
                       recompile=True,
                       reprime=False,
                       epsilon_schedule=None,
                       eval_epsilon=None,
                       overcompensate_eps=1.,
                       kernel_regularization='l1_0.0001,l2_0',
                       lr_decay=None,
                       spectral_tolerance=1.e-10,
                       data_augmentation=None,
                       warmup=0,
                       start_checkpoint=0,
                       lowerbound_layerlip=None,
                       use_power_reg=False, 
                       use_ortho_init=False,
                       _start_model=None,
                       early_stop=None,
                       do_precise_timing=False,
                       device=None):

    callbacks = []
    margin_callbacks = []

    if early_stop is not None:
        callbacks.append(tf.keras.callbacks.EarlyStopping(monitor='val_loss', 
                                         min_delta=1e-3, 
                                         patience=int(early_stop), 
                                         verbose=0, 
                                         mode='min', 
                                         baseline=None, 
                                         restore_best_weights=False))
        print("Use early stop. This is only recommended to use for training regular models.")

    if norm == 'linf' and not lipschitz_bound.startswith('spectral'):
        raise ValueError(
            'Linf is only supported for layer-wise lipschitz computation now.')

    K.set_image_data_format('channels_last')

    # Create a data augmentation pipeline
    data_preprocesser = None
    data_generator = None
    if isinstance(data_augmentation, str):
        if data_augmentation == 'default':
            data_generator = DataPipeline(str(data_augmentation))(data.x_tr)
        elif data_augmentation == 'gpu_default':
            data_preprocesser = ImageDataPipeline(data)

    if _start_model is None:
        f = string_to_architecture(data, architecture, preprocess_layer=data_preprocesser, use_power_reg=use_power_reg, use_ortho_init=use_ortho_init)
    else:
        f_margin = tf.keras.models.load_model(_start_model, custom_objects={'ConstantSpectralMargin': ConstantSpectralMargin})
        f = Model(f_margin.input, f_margin.layers[-2].output)

    if warmup > 0 and epochs == 0:
        # this is just for evaluation purposes
        f.compile(
            loss=tf.keras.losses.CategoricalCrossentropy(from_logits=True),
            optimizer='adam',
            metrics=['acc'])
        f = train_network(f,
                          data.x_tr,
                          data.y_tr_1hot,
                          data_generator=data_generator,
                          data_preprocesser=data_preprocesser,
                          batch_size=batch_size,
                          epochs=warmup,
                          validation_data=(data.x_te, data.y_te_1hot),
                          callbacks=callbacks,
                          do_precise_timing=do_precise_timing)
        return None

    if loss == 'crossentropy':
        loss = tf.keras.losses.CategoricalCrossentropy(from_logits=True)
    elif 'trades' in loss:
        use_kl = "kl" in loss
        trades_params = loss.split(',')
        lam = tf.Variable(float(trades_params[1]),
                          trainable=False,
                          name='trades_param')
        loss = MarginTradesLoss(lam, use_kl=use_kl)
        trades_callback = TradesScheduler(lam, float(trades_params[1]),
                                          float(trades_params[2]),
                                          int(trades_params[3]))
        margin_callbacks += [trades_callback]
    else:
        raise ValueError(
            f'loss must be one of \'crossentropy\' or \'trades\', {loss} not recognized'
        )

    x = f.input
    y = f.output

    if lipschitz_bound == 'global':
        l = global_lipschitz_bound(f)

        y_margin_over = LipschitzMargin(epsilon * overcompensate_eps)(y, l)
        y_margin = LipschitzMargin(epsilon)(y, l)

        model_over = Model(x, y_margin_over)
        model = Model(x, y_margin)

    elif lipschitz_bound == 'fastlip':
        l = fastlip([l for l in f.layers if l.get_weights()], epsilon)

        y_margin_over = LipschitzMargin(epsilon * overcompensate_eps)(y, l)
        y_margin = LipschitzMargin(epsilon)(y, l)

        model_over = Model(x, y_margin_over)
        model = Model(x, y_margin)

    elif lipschitz_bound == 'global-to-fastlip':
        l = fastlip([l for l in f.layers if l.get_weights()], epsilon)
        k = global_lipschitz_bound(f)

        if overcompensate_eps == 1.:
            overcompensate_eps = 1.0001

        y_margin_over = LipschitzMargin(epsilon * overcompensate_eps)(y, k)
        y_margin = LipschitzMargin(epsilon)(y, l)

        model_over = Model(x, y_margin_over)
        model = Model(x, y_margin)

    elif lipschitz_bound == 'fastlin':
        l, u = fl([l for l in f.layers if l.get_weights()], epsilon)

        y_margin_over = FlMargin(epsilon * overcompensate_eps)(y, l, u)
        y_margin = FlMargin(epsilon)(y, l, u)

        model_over = Model(x, y_margin_over)
        model = Model(x, y_margin)

    elif lipschitz_bound == 'global-to-fastlin':
        l, u = fl([l for l in f.layers if l.get_weights()], epsilon)
        k = global_lipschitz_bound(f)

        if overcompensate_eps == 1.:
            overcompensate_eps = 1.0001

        y_margin_over = LipschitzMargin(epsilon * overcompensate_eps)(y, k)
        y_margin = FlMargin(epsilon)(y, l, u)

        model_over = Model(x, y_margin_over)
        model = Model(x, y_margin)

    elif lipschitz_bound.startswith('spectral'):
        if 'svd_all' in lipschitz_bound:
            use_svd = 'all'
        elif 'power_all' in lipschitz_bound:
            use_svd = 'none'
        else:
            use_svd = 'conv'
        if len(lipschitz_bound.split('.')) > 1:
            num_iterations = int(lipschitz_bound.split('.')[1])
        else:
            num_iterations = 10

        xs = {}
        asgns = {}

        if use_svd != 'all':
            for layer in f.layers:
                if hasattr(layer, 'kernel'):
                    if len(layer.kernel.shape) == 4:
                        xs[layer.name] = tf.keras.backend.variable(
                            tf.random.truncated_normal(shape=(1, ) +
                                                       layer.input_shape[1:]),
                            name='{}_pk'.format(layer.name))
                        asgns[layer.name] = tf.compat.v1.assign(
                            xs[layer.name],
                            tf.random.truncated_normal(shape=(1, ) +
                                                       layer.input_shape[1:]))
                    else:
                        xs[layer.name] = tf.keras.backend.variable(
                            tf.random.truncated_normal(
                                shape=(int(layer.kernel.shape[1]), 1)),
                            name='{}_pk'.format(layer.name))
                        asgns[layer.name] = tf.compat.v1.assign(
                            xs[layer.name],
                            tf.random.truncated_normal(
                                shape=(int(layer.kernel.shape[1]), 1)))

        # It is not necessary to use a lowerbound for a regular feedforward network.
        if isinstance(lowerbound_layerlip, str) and lowerbound_layerlip == 'default':
            lowerbound_layerlip = DEFAULT_LOWERBOUND

        l, updates, all_ks = global_lipschitz_bound_spectral(
            f,
            use_svd=use_svd,
            num_iterations=num_iterations,
            warm_start_xs=xs,
            lowerbound_layerlip=lowerbound_layerlip,
            norm=norm)

        # l = global_lipschitz_bound_spectral_power(f, num_iterations=num_iterations, norm=norm)
        # else:
        #     raise ValueError(
        #         "Only 'l2' and 'linf' are supported but got {}".format(norm))

        y_margin_over = SpectralMargin(epsilon * overcompensate_eps,
                                       f.layers[-1].weights[0])(y, l)
        y_margin = SpectralMargin(epsilon, f.layers[-1].weights[0])(y, l)
        y_margin_test = SpectralMargin(epsilon, f.layers[-1].weights[0])(y, l)
        l_func = K.function([], [l])
        all_ks_func = K.function([], all_ks)

        if norm in ['l2', 'linf'] and not ('svd_all' in lipschitz_bound):
            spectral_updates = SpectralStateUpdate(updates, xs, asgns, l_func,
                                                   all_ks_func,
                                                   spectral_tolerance)
            margin_callbacks.append(spectral_updates)

        model_over = Model(x, y_margin_over)
        model = Model(x, y_margin)
        model_test = Model(x, y_margin_test)

    else:
        raise ValueError(
            f'unknown Lipschitz bound algorithm: {lipschitz_bound}')

    if kernel_regularization is not None:
        reg = kernel_regularization.split(',')
        l1, l2 = reg[0].split('_')[1], reg[1].split('_')[1]
        regularizer = tf.keras.regularizers.L1L2(l1=l1, l2=l2)
        for layer in model.layers:
            if hasattr(layer, 'kernel_regularizer'):
                setattr(layer, 'kernel_regularizer', regularizer)
        for layer in model_over.layers:
            if hasattr(layer, 'kernel_regularizer'):
                setattr(layer, 'kernel_regularizer', regularizer)

    print(model.summary())

    if not (epsilon_schedule is None or epsilon_schedule == 'single'):
        eps_schedule = EpsilonScheduler(model, epsilon_schedule[0],
                                        epsilon_schedule[1],
                                        epsilon_schedule[2])
        margin_callbacks += [eps_schedule]
        margin_callbacks += [
            EvalEpsilonCallback(model, eval_epsilon, epsilon_schedule[2])
        ]
    else:
        if eval_epsilon != None or eval_epsilon != epsilon:
            margin_callbacks += [EvalEpsilonCallback(model, eval_epsilon)]

    if optimizer == 'sgd':
        optimizer_params = {'learning_rate': learning_rate, 'momentum': 0.1}
    else:
        optimizer_params = {'learning_rate': learning_rate}
    opt_str = optimizer
    optimizer = lambda: optimizers.get(opt_str).__class__(**optimizer_params)

    y_tr_extra_column = add_extra_column(data.y_tr_1hot)
    y_te_extra_column = add_extra_column(data.y_te_1hot)

    orig_epsilon = epsilon

    temp_dir = tempfile.mkdtemp(prefix='tmp-models_')
    try:
        os.mkdir(temp_dir)
    except:
        pass
    checkpoint = DelayedCheckpoint(
        model, 
        os.path.join(temp_dir, 'chkpoint.h5'), 
        start_at_epoch=start_checkpoint)
    callbacks += [checkpoint]

    if warmup > 0:
        f.compile(
            loss=tf.keras.losses.CategoricalCrossentropy(from_logits=True),
            optimizer=optimizer(),
            metrics=['acc'])

        f = train_network(f,
                          data.x_tr,
                          data.y_tr_1hot,
                          data_generator=data_generator,
                          data_preprocesser=data_preprocesser,
                          batch_size=batch_size,
                          epochs=warmup,
                          validation_data=(data.x_te, data.y_te_1hot),
                          callbacks=callbacks + [spectral_updates],
                          do_precise_timing=do_precise_timing)

    if training_strategy in ('alternate_half', 'alternate_3-4',
                             'alternate_full'):
        f.compile(
            loss=tf.keras.losses.CategoricalCrossentropy(from_logits=True),
            metrics=['acc'])

        model.compile(loss=loss, optimizer=optimizer(), metrics=['acc'])

        try:
            model_test.compile(loss=loss,
                               optimizer=optimizer(),
                               metrics=['acc'])
        except:
            pass

        if overcompensate_eps != 1.:
            model_over.compile(loss=loss,
                               optimizer=optimizer(),
                               metrics=['acc'])

        if reprime:
            epoch_schedule = [epochs - epochs // 2, epochs // 2]
        else:
            epoch_schedule = [epochs]

        for epochs in epoch_schedule:
            half_way_point = (
                3 * epochs // 4 if training_strategy == 'alternate_3-4' else
                (epochs //
                 2 if training_strategy == 'alternate_half' else epochs))

            epochs_so_far = 0

            if lr_decay is not None:
                if lr_decay.startswith('halfdelayed'):
                    lr_decay_str = lr_decay.split(',')
                    callbacks += [
                        HalfLrScheduler(initial_lr=learning_rate,
                                        start_decay_epoch=int(lr_decay_str[1]),
                                        decay_stages=int(lr_decay_str[2]),
                                        total_epochs=epochs,
                                        smallest_lr=float(lr_decay_str[3]))
                    ]
                elif lr_decay.startswith('half'):
                    lr_decay_str = lr_decay.split(',')
                    callbacks += [
                        HalfLrScheduler(initial_lr=learning_rate,
                                        start_decay_epoch=0,
                                        decay_stages=int(lr_decay_str[1]),
                                        total_epochs=epochs,
                                        smallest_lr=float(lr_decay_str[2]))
                    ]
                elif 'linear' in lr_decay:
                    lr_decay_str = lr_decay.split(',')
                    callbacks += [
                        LinearLrScheduler(initial_lr=learning_rate,
                                          start_decay_epoch=int(
                                              lr_decay_str[1]),
                                          total_epochs=epochs,
                                          smallest_lr=float(lr_decay_str[2]))
                    ]
                elif 'gamma_decay' in lr_decay.split(','):
                    lr_decay_str = lr_decay.split(',')
                    callbacks += [
                        ScaledLrScheduler(initial_lr=learning_rate,
                                          start_decay_epoch=int(
                                              lr_decay_str[1]),
                                          total_epochs=epochs,
                                          scaled_by=float(lr_decay_str[3]),
                                          smallest_lr=float(lr_decay_str[2]))
                    ]
                else:
                    callbacks += [
                        ContinuousExponentialLrScheduler(lr_decay, epochs)
                    ]

            while epochs_so_far < half_way_point:
                f = train_network(f,
                                  data.x_tr,
                                  data.y_tr_1hot,
                                  data_generator=data_generator,
                                  data_preprocesser=data_preprocesser,
                                  batch_size=batch_size,
                                  epochs=alternate_rate,
                                  validation_data=(data.x_te, data.y_te_1hot),
                                  callbacks=callbacks,
                                  do_precise_timing=do_precise_timing)

                if overcompensate_eps != 1.:
                    print(
                        f'\nTraining overcompensate @ epsilon={overcompensate_eps*epsilon}'
                    )
                    model_over = train_network(
                        model_over,
                        data.x_tr,
                        y_tr_extra_column,
                        data_generator=data_generator,
                        data_preprocesser=data_preprocesser,
                        batch_size=batch_size,
                        epochs=alternate_rate,
                        validation_data=(data.x_te, y_te_extra_column),
                        callbacks=callbacks + margin_callbacks,
                        do_precise_timing=do_precise_timing)
                else:
                    model = train_network(
                        model,
                        data.x_tr,
                        y_tr_extra_column,
                        data_generator=data_generator,
                        data_preprocesser=data_preprocesser,
                        batch_size=batch_size,
                        epochs=alternate_rate,
                        validation_data=(data.x_te, y_te_extra_column),
                        callbacks=callbacks + margin_callbacks,
                        do_precise_timing=do_precise_timing)

                epochs_so_far += 2 * alternate_rate

                print(f'--- Completed Epoch {epochs_so_far} / {epochs} ---')

            if recompile:
                model.compile(loss=loss,
                              optimizer=optimizer(),
                              metrics=['acc'])

            model = train_network(model,
                                  data.x_tr,
                                  y_tr_extra_column,
                                  data_generator=data_generator,
                                  batch_size=batch_size,
                                  epochs=epochs - epochs_so_far,
                                  validation_data=(data.x_te,
                                                   y_te_extra_column),
                                  callbacks=callbacks + margin_callbacks,
                                  do_precise_timing=do_precise_timing)

            if len(epoch_schedule) > 1:
                optimizer_params['learning_rate'] = learning_rate / 2.

    elif training_strategy == 'standard':
        if lr_decay is not None:
            if lr_decay.startswith('halfdelayed'):
                lr_decay_str = lr_decay.split(',')
                callbacks += [
                    HalfLrScheduler(initial_lr=learning_rate,
                                    start_decay_epoch=int(lr_decay_str[1]),
                                    decay_stages=int(lr_decay_str[2]),
                                    total_epochs=epochs,
                                    smallest_lr=float(lr_decay_str[3]))
                ]
            elif lr_decay.startswith('half'):
                lr_decay_str = lr_decay.split(',')
                callbacks += [
                    HalfLrScheduler(initial_lr=learning_rate,
                                    decay_stages=int(lr_decay_str[1]),
                                    total_epochs=epochs,
                                    smallest_lr=float(lr_decay_str[2]))
                ]
            elif 'linear' in lr_decay:
                lr_decay_str = lr_decay.split(',')
                callbacks += [
                    LinearLrScheduler(initial_lr=learning_rate,
                                      start_decay_epoch=int(lr_decay_str[1]),
                                      total_epochs=epochs,
                                      smallest_lr=float(lr_decay_str[2]))
                ]
            elif 'gamma_decay' in lr_decay.split(','):
                lr_decay_str = lr_decay.split(',')
                callbacks += [
                    ScaledLrScheduler(initial_lr=learning_rate,
                                        start_decay_epoch=int(
                                            lr_decay_str[1]),
                                        total_epochs=epochs,
                                        scaled_by=float(lr_decay_str[3]),
                                        smallest_lr=float(lr_decay_str[2]))
                ]
            else:
                callbacks += [
                    ContinuousExponentialLrScheduler(lr_decay, epochs)
                ]
        if epsilon == 0.0:
            f.compile(loss=loss, optimizer=optimizer(), metrics=['acc'])
            f = train_network(f,
                              data.x_tr,
                              data.y_tr_1hot,
                              data_generator=data_generator,
                              data_preprocesser=data_preprocesser,
                              batch_size=batch_size,
                              epochs=epochs,
                              validation_data=(data.x_te, data.y_te_1hot),
                              callbacks=callbacks,
                              do_precise_timing=do_precise_timing)

        else:
            model.compile(loss=loss, optimizer=optimizer(), metrics=['acc'])
            model = train_network(model,
                                  data.x_tr,
                                  y_tr_extra_column,
                                  data_generator=data_generator,
                                  data_preprocesser=data_preprocesser,
                                  batch_size=batch_size,
                                  epochs=epochs,
                                  validation_data=(data.x_te,
                                                   y_te_extra_column),
                                  callbacks=callbacks + margin_callbacks,
                                  do_precise_timing=do_precise_timing)

    else:
        raise ValueError(f'unknown training strategy: {training_strategy}')

    model.load_weights(os.path.join(temp_dir, 'chkpoint.h5'))
    os.remove(os.path.join(temp_dir, 'chkpoint.h5'))
    os.rmdir(temp_dir)

    if 'spectral_power' in lipschitz_bound:
        print('\n---- calculating more accurate lipschitz bound')
        print(f'current: {tf.keras.backend.get_value(l)}')
        k_c = l_func([])[0]
        k_l = np.infty
        # print(k_c, end='', flush=True)
        while np.abs(k_c - k_l) >= spectral_tolerance:
            print('.', end='', flush=True)
            spectral_updates._upd_func([])
            k_l = k_c
            k_c = l_func([])[0]
        # print(k_c, end='\n')
        l_final_const = k_c
        print(f'updated: {l_final_const}')
        y_margin_final = ConstantSpectralMargin(
            eval_epsilon, tf.keras.backend.get_value(l_final_const),
            f.layers[-1].weights[0])(y)
        model_final = Model(x, y_margin_final)
        model_final.compile(loss=CategoricalCrossentropy(from_logits=True),
                            optimizer=optimizer(),
                            metrics=['acc'])
        return model_final

    else:
        return model


if __name__ == '__main__':

    @scriptify
    def script(dataset,
               architecture,
               epsilon,
               norm='l2',
               lipschitz_bound='global',
               loss='crossentropy',
               training_strategy='alternate_half',
               optimizer='adam',
               learning_rate=1e-4,
               epochs=200,
               batch_size=128,
               alternate_rate=1,
               dont_recompile=False,
               normalization='normalize_01',
               overcompensate_eps=1.,
               reprime=False,
               epsilon_schedule='single',
               eval_epsilon=None,
               kernel_regularization='l1_0.0,l2_0.0',
               lr_decay=None,
               spectral_tolerance=1.e-4,
               data_augmentation=None,
               warmup=0,
               start_checkpoint=0,
               test_lip_bound=False,
               lowerbound_layerlip=None,
               use_power_reg=False, 
               use_ortho_init=False,
               start_from_file=None,
               early_stop=None,
               do_precise_timing=False,
               gpu=0):

        # Select the GPU and allow memory growth to avoid taking all the RAM.
        gpus = tf.config.experimental.list_physical_devices('GPU')
        tf.config.experimental.set_visible_devices(gpus[gpu], 'GPU')
        device = gpus[gpu]

        for device in tf.config.experimental.get_visible_devices('GPU'):
            tf.config.experimental.set_memory_growth(device, True)

        if not isinstance(architecture, str):
            architecture = str(architecture)

        if architecture.startswith('<'):
            architecture = architecture[1:-1]

        processors = None
        if normalization == 'normalize_-11':
            processors = [Normalize(-1, 1)]
        elif normalization == 'unitball':
            processors = ['normalize']

        if dataset == 'mnist':
            data = Mnist(processors=processors)
        elif dataset == 'cifar':
            data = Cifar10(processors=processors)
        elif dataset == 'lfw':
            data = Lfw(processors=None, min_faces_per_person=50, color=True)
        elif dataset == 'fmnist':
            data = FashionMnist(processors=processors)
        elif dataset == 'tiny_imagenet':
            data = TinyImagenet(processors=processors)
        else:
            raise ValueError(f'unknown dataset; {dataset}')

        ### TODO: gradual_10, gradual_16, and logarithmic are currently broken
        ### need to update them to work with the new EpsilonSchedule callback
        if epsilon_schedule == 'gradual_10':
            epsilon_schedule = list(epsilon * np.array(
                [0.0001, 0.001, 0.01, 0.05, 0.1, 0.25, 0.5, 0.75, 1.1, 1.0]))

        elif epsilon_schedule == 'gradual_16':
            epsilon_schedule = list(epsilon * np.array([
                0.0001, 0.0005, 0.001, 0.005, 0.01, 0.025, 0.05, 0.075, 0.1,
                0.25, 0.5, 0.75, 1.0, 1.25, 1.1, 1.0
            ]))

        elif epsilon_schedule.startswith('logarithmic_'):
            steps = int(epsilon_schedule.split('logarithmic_')[1])

            initial = 0.0001
            final = 1.1

            epsilon_schedule = [
                epsilon * np.log((np.exp(final) - np.exp(initial)) /
                                 (steps - 2) * i + np.exp(initial))
                for i in range(steps - 1)
            ] + [1.0]

        elif not (epsilon_schedule == 'single'):
            epsilon_schedule = [
                float(eps) for eps in epsilon_schedule.split(',')
            ]

        if eval_epsilon is None:
            eval_epsilon = epsilon
        if normalization == 'normalize_-11':
            epsilon = 2 * epsilon
            eval_epsilon = 2 * epsilon
            if not (epsilon_schedule == 'single'):
                epsilon_schedule[0] = 2 * epsilon_schedule[0]
                epsilon_schedule[1] = 2 * epsilon_schedule[1]
        elif normalization == 'unitball':
            flat_x = data.x_tr.reshape((len(data.x_tr), -1))
            norms = np.linalg.norm(flat_x, axis=1, keepdims=True)
            mean = flat_x.mean()
            flat_x -= mean
            flat_x /= norms
            data.x_tr = flat_x.reshape(data.x_tr.shape)
            data.x_te -= mean
            data.x_te /= norms.mean().astype('float32')
            epsilon = float(epsilon / norms.mean())
            eval_epsilon = float(eval_epsilon / norms.mean())
            if not (epsilon_schedule == 'single'):
                epsilon_schedule[0] = float(epsilon_schedule[0] / norms.mean())
                epsilon_schedule[1] = float(epsilon_schedule[1] / norms.mean())

        print('.' * 80)
        print('training model')
        print('.' * 80)

        start_time = time()

        model = train_margin_model(data,
                                   architecture,
                                   epsilon,
                                   norm=norm,
                                   lipschitz_bound=lipschitz_bound,
                                   loss=loss,
                                   training_strategy=training_strategy,
                                   optimizer=optimizer,
                                   learning_rate=learning_rate,
                                   epochs=epochs,
                                   batch_size=batch_size,
                                   alternate_rate=alternate_rate,
                                   recompile=not dont_recompile,
                                   reprime=reprime,
                                   epsilon_schedule=epsilon_schedule,
                                   eval_epsilon=eval_epsilon,
                                   overcompensate_eps=overcompensate_eps,
                                   kernel_regularization=kernel_regularization,
                                   lr_decay=lr_decay,
                                   spectral_tolerance=spectral_tolerance,
                                   data_augmentation=data_augmentation,
                                   warmup=warmup,
                                   start_checkpoint=start_checkpoint,
                                   lowerbound_layerlip=lowerbound_layerlip,
                                   use_power_reg=use_power_reg, 
                                   use_ortho_init=use_ortho_init,
                                   _start_model=start_from_file,
                                   early_stop=early_stop,
                                   do_precise_timing=do_precise_timing,
                                   device=device)

        end_time = time()

        total_time = end_time - start_time
        time_per_epoch = total_time / (epochs + 1e-20) # in case of regular training

        print(f'\n>> done in {total_time} seconds\n')

        model_file = model._filename + '.h5'

        print('.' * 80)
        print('calculating accuracy')
        print('.' * 80)

        vra = (model.predict(data.x_te).argmax(axis=1) == data.y_te).mean()
        vra_train = (model.predict(
            data.x_tr).argmax(axis=1) == data.y_tr).mean()
        clean_acc = (model.predict(
            data.x_te)[:, :-1].argmax(axis=1) == data.y_te).mean()
        clean_acc_train = (model.predict(
            data.x_tr)[:, :-1].argmax(axis=1) == data.y_tr).mean()

        print(f'VRA: {vra}')

        if test_lip_bound:
            m = tf.keras.Model(model.input, model.layers[-2].output)

            l = global_lipschitz_bound_spectral_power(m,
                                                      num_iterations=10000,
                                                      norm=norm)

            l_func = tf.keras.backend.function([], [tf.reduce_max(l)])
            k = l_func([])[0]
            print(f'\nK = {k}')
            model.layers[-1].k = k

            idx = np.random.randint(0, len(data.x_te) - 1)
            x1 = tf.keras.backend.variable(data.x_te[idx][None],
                                           dtype=tf.float32)
            x2 = tf.keras.backend.variable(data.x_te[idx + 1][None],
                                           dtype=tf.float32)

            out_iters = 10
            in_iters = 1000

            opt = tf.keras.optimizers.Adam()
            obj = -(tf.reduce_max(
                tf.sqrt(tf.square(m(x1)[0] - m(x2)[0]) + 1.e-12)
            ) / (tf.sqrt(
                tf.reduce_sum(tf.square((tf.reshape(x1[0] - x2[0],
                                                    (-1, ))))) + 1.e-12)))
            g = tf.gradients(obj, [x1, x2])
            mof = tf.keras.backend.function(
                [], [obj], [opt.apply_gradients(zip(g, [x1, x2]))])
            max_vv = -1
            for _ in range(out_iters):
                pb = Progbar(in_iters, stateful_metrics=['K'])
                for i in range(in_iters):
                    vv = -mof([])[0]
                    if vv > max_vv:
                        max_vv = vv
                    pb.add(1, [('K', max_vv)])

            print(f'\nFinal K={max_vv}')
            if max_vv < k:
                print(f'This is correct for global bound {k}')
            else:
                print(f'This is not correct for global bound {k}')

        return {
            'vra': vra,
            'clean_acc': clean_acc,
            'vra_train': vra_train,
            'clean_acc_train': clean_acc_train,
            'time_per_epoch': time_per_epoch,
            'model_file': model_file
        }
