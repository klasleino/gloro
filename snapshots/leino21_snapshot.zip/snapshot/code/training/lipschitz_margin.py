import numpy as np
import tensorflow as tf

from tensorflow.keras import backend as K
from tensorflow.keras.layers import Layer
from tensorflow.keras.layers import Flatten
from tensorflow.keras.losses import CategoricalCrossentropy
from tensorflow.keras.losses import KLDivergence
from tensorflow.keras.layers import Activation


def MarginTradesLoss(lam, use_kl=False):
    ce_loss = CategoricalCrossentropy(from_logits=True)
    
    if not use_kl:
        robust_loss = CategoricalCrossentropy(from_logits=False)
    else:
        robust_loss = KLDivergence()
    def loss(y_true, y_pred):
        ce = ce_loss(y_true[:, :-1], y_pred[:, :-1])
        log_true = tf.concat(
            (tf.nn.softmax(y_pred[:, :-1]), tf.zeros(
                (tf.shape(y_true)[0], 1))),
            axis=1)
        tr = robust_loss(log_true, tf.nn.softmax(y_pred))

        return ce + lam * tr

    return loss

def LMTLoss(k, epsilon):
    ce_loss = CategoricalCrossentropy(from_logits=True)
    factor = np.sqrt(2)*k*epsilon
    
    def loss(y_true, y_pred):
        # add sqrt(2)*K*epsilon to all logits except the correct class
        class_mask = tf.cast(
            factor*(1.0-tf.equal(y_true, K.max(y_true, axis=1, keepdims=True))), 
            'float32')
        return ce_loss(y_true, y_pred+class_mask)



def l2_norm_of_kernel(layer):

    W = layer.kernel

    padding = layer.padding
    strides = layer.strides[0]

    # Currently we only support strides of 1.
    if strides > 1:
        raise ValueError('strides greater than 1 not supported')

    # For channels LAST.
    _, h_in, w_in, c_in = layer.input_shape
    _, h_out, w_out, c_out = layer.output_shape

    kernel_size = K.int_shape(W)[0]

    padding_start = int(np.ceil((kernel_size - 1) / strides)) // 2
    padding_end = int(np.ceil((kernel_size - 1) / strides)) - padding_start

    kernel = W

    # Obnoxiously, `conv2d_transpose` requires us to specify the output shape,
    # even though this should be calculated based on the kernel size, strides,
    # etc. To avoid having to recreate that logic, we'll just use a
    # `Conv2DTranspose` layer, which calculates the output shape for us.
    l = tf.keras.layers.Conv2DTranspose(1,
                                        kernel_size,
                                        dilation_rate=strides,
                                        padding=padding)
    expected_output_shape = K.int_shape(
        l(np.ones((c_in, kernel_size, kernel_size, c_out), dtype=np.float32)))

    template = K.sqrt(
        K.conv2d_transpose(K.permute_dimensions(kernel, (2, 0, 1, 3))**2,
                           np.ones((kernel_size, kernel_size, 1, c_out),
                                   dtype=np.float32),
                           output_shape=expected_output_shape,
                           strides=(1, 1),
                           dilation_rate=(strides, strides),
                           padding=padding))

    padding_start += (expected_output_shape[1] - kernel_size) // 2
    padding_end += (expected_output_shape[1] - kernel_size) // 2

    padding_array_h = ([1 for _ in range(padding_start)] +
                       [h_in - padding_start - padding_end] +
                       [1 for _ in range(padding_end)])
    padding_array_w = ([1 for _ in range(padding_start)] +
                       [w_in - padding_start - padding_end] +
                       [1 for _ in range(padding_end)])

    template = tf.repeat(tf.repeat(template, padding_array_h, axis=1),
                         padding_array_w,
                         axis=2)

    return K.permute_dimensions(template[:, :, :, 0], (1, 2, 0))


def l2_norm_of_kernel_axis0(W, padding, strides, h_out, w_out):
    kernel_size, _, c_in, c_out = K.int_shape(W)

    padding_start = int(np.ceil((kernel_size - 1) / strides)) // 2
    padding_end = int(np.ceil((kernel_size - 1) / strides)) - padding_start

    kernel = tf.pad(W, [
        [padding_end, padding_start],
        [padding_end, padding_start],
        [0, 0],
        [0, 0],
    ]) if padding == 'same' else W

    # For channels LAST.
    template = K.sqrt(
        K.conv2d(K.permute_dimensions(kernel, (3, 0, 1, 2))**2,
                 np.ones((kernel_size, kernel_size, c_in, 1),
                         dtype=np.float32),
                 strides=1,
                 padding='valid'))

    # Need to rotate.
    template = tf.image.rot90(template, 2)
    # print(template)

    if padding == 'valid':
        padding_array_h = [h_out]
        padding_array_w = [w_out]

    elif padding == 'same':
        padding_array_h = ([1 for _ in range(padding_start)] +
                           [h_out - padding_start - padding_end] +
                           [1 for _ in range(padding_end)])
        padding_array_w = ([1 for _ in range(padding_start)] +
                           [w_out - padding_start - padding_end] +
                           [1 for _ in range(padding_end)])

        # print(padding_array_h)

    template = tf.repeat(tf.repeat(template, padding_array_h, axis=1),
                         padding_array_w,
                         axis=2)

    return K.permute_dimensions(template[:, :, :, 0], (1, 2, 0))


def get_Y(Y1_c, Y1_del, A_fixed, A_free, W2):
    if W2 is None:
        return Y1_c[None], 0.

    elif Y1_del == 0.:
        W1 = Y1_c
        W2 = W2[None]

        Y2_c = (W1 * A_fixed) @ W2

        Y2_del = (K.abs(W1) * A_free) @ K.abs(W2)

        return Y2_c, Y2_del

    else:
        W2 = W2[None]

        Y2_c = (Y1_c * A_fixed) @ W2

        Y2_del = (K.abs(Y1_del) * A_fixed) @ K.abs(W2) + ((
            (K.abs(Y1_c) + K.abs(Y1_del)) * A_free) @ K.abs(W2))

        return Y2_c, Y2_del


def get_Y_rev(Y1_c, Y1_del, A_fixed, A_free, W2):
    if W2 is None:
        return K.transpose(Y1_c)[None], 0.

    elif Y1_del == 0.:
        W1 = Y1_c
        W2 = K.transpose(W2)[None]

        Y2_c = (W1 * A_fixed) @ W2

        Y2_del = (K.abs(W1) * A_free) @ K.abs(W2)

        return Y2_c, Y2_del

    else:
        W2 = K.transpose(W2)[None]

        Y2_c = (Y1_c * A_fixed) @ W2

        Y2_del = (K.abs(Y1_del) * A_fixed) @ K.abs(W2) + ((
            (K.abs(Y1_c) + K.abs(Y1_del)) * A_free) @ K.abs(W2))

        return Y2_c, Y2_del


def get_k(Y_c, Y_del):
    return tf.norm(K.maximum(K.abs(Y_c + Y_del), K.abs(Y_c - Y_del)), axis=1)


def get_A(z_x, k, eps):
    z_l, z_u = z_x - eps * k, z_x + eps * k

    A_fixed = tf.cast(z_l >= 0, 'float32')[:, None]
    A_free = (tf.cast(z_l < 0, 'float32') * tf.cast(z_u > 0, 'float32'))[:,
                                                                         None]

    return A_fixed, A_free


def local_lipschitz_bound(model, epsilon):
    layers = [layer for layer in model.layers if layer.get_weights()]
    W = [w for w in model.weights if 'kernel' in w.name]

    Y_c, Y_del = get_Y(W[0], 0., None, None, None)
    k = get_k(Y_c, Y_del)

    for i, layer in enumerate(layers[:-1]):
        A_fixed, A_free = get_A(layer.output, k, epsilon)

        Y_c, Y_del = get_Y(Y_c, Y_del, A_fixed, A_free, W[i + 1])

        k = get_k(Y_c, Y_del)

    return k


def local_lipschitz_bound(model, epsilon):
    layers = [layer for layer in model.layers if layer.get_weights()]
    W = [w for w in model.weights if 'kernel' in w.name]

    Y_c, Y_del = get_Y(W[0], 0., None, None, None)
    k = get_k(Y_c, Y_del)

    for i, layer in enumerate(layers[:-1]):
        A_fixed, A_free = get_A(layer.output, k, epsilon)

        Y_c, Y_del = get_Y(Y_c, Y_del, A_fixed, A_free, W[i + 1])

        k = get_k(Y_c, Y_del)

    return k


# def global_lipschitz_bound(model):
#     Ws = [W for W in model.weights if 'kernel' in W.name]

#     k = None
#     for W in Ws:
#         if k is None:
#             k = K.abs(W)

#         else:
#             k = k @ K.abs(W)

#     return tf.norm(k, axis=0)[None]


def get_Y_conv(Y1_c, Y1_del, A_fixed, A_free, W2, layer, input_shape):

    if W2 is None:
        print('hi')
        _, c, h, w = layer.input_shape
        print(f'h, w, c: {h}, {w}, {c}')
        W1 = Y1_c
        print(f'W1: {W1}')

        return K.conv2d(K.reshape(K.eye(c * h * w), [c * h * w, c, h, w]),
                        W1,
                        padding=layer.padding,
                        strides=layer.strides)[None], 0.

    elif Y1_del == 0.:
        _, c_in, h_in, w_in = layer.input_shape
        _, c_out, h_out, w_out = layer.output_shape

        W1 = Y1_c

        # Y2_c = (W1 * A_fixed) @ W2

        # Y2_del = (K.abs(W1) * A_free) @ K.abs(W2)

        Y2_c = K.reshape(
            K.conv2d(K.reshape(W1 * A_fixed, (-1, c_in, h_in, w_in)),
                     W2,
                     padding=layer.padding,
                     strides=layer.strides),
            (-1, np.prod(input_shape), c_out, h_out, w_out))

        Y2_del = K.reshape(
            K.conv2d(K.reshape(K.abs(W1) * A_free, (-1, c_in, h_in, w_in)),
                     K.abs(W2),
                     padding=layer.padding,
                     strides=layer.strides),
            (-1, np.prod(input_shape), c_out, h_out, w_out))

        return Y2_c, Y_del

    else:
        # Y2_c = (Y1_c * A_fixed) @ W2

        # Y2_del = (K.abs(Y1_del) * A_fixed) @ K.abs(W2) + (
        #     ((K.abs(Y1_c) + K.abs(Y1_del)) * A_free) @ K.abs(W2))

        Y2_c = K.reshape(
            K.conv2d(K.reshape(Y1_c * A_fixed, (-1, c_in, h_in, w_in)),
                     W2,
                     padding=layer.padding,
                     strides=layer.strides),
            (-1, np.prod(input_shape), c_out, h_out, w_out))

        Y2_del = K.reshape((K.conv2d(
            K.reshape(K.abs(Y1_del) * A_fixed, (-1, c_in, h_in, w_in)),
            K.abs(W2),
            padding=layer.padding,
            strides=layer.strides) + K.conv2d(K.reshape(
                (K.abs(Y1_c) + K.abs(Y1_del)) * A_free,
                (-1, c_in, h_in, w_in)),
                                              K.abs(W2),
                                              padding=layer.padding,
                                              strides=layer.strides)),
                           (-1, np.prod(input_shape), c_out, h_out, w_out))

        return Y2_c, Y2_del


def get_k_conv(Y_c, Y_del):
    _, inputs, c, h, w = K.int_shape(Y_c)

    Y_c = K.reshape(Y_c, (-1, inputs, c * h * w))
    Y_del = K.reshape(Y_del, (-1, inputs, c * h * w))

    k = tf.norm(K.maximum(K.abs(Y_c + Y_del), K.abs(Y_c - Y_del)), axis=1)

    return K.reshape(k, (-1, c, h, w))


def get_A_conv(z_x, k, eps):
    z_l, z_u = z_x - eps * k, z_x + eps * k

    A_fixed = tf.cast(z_l >= 0, 'float32')[:, None]
    A_free = (tf.cast(z_l < 0, 'float32') * tf.cast(z_u > 0, 'float32'))[:,
                                                                         None]

    return A_fixed, A_free


def local_lipschitz_bound2(model, epsilon):
    layers = [layer for layer in model.layers if layer.get_weights()]
    W = [w for w in model.weights if 'kernel' in w.name]

    Y_c, Y_del = get_Y(W[0], 0., None, None, None)
    k = get_k(Y_c, Y_del)

    input_shape = model.input_shape[1:]

    flat = False

    for i, layer in enumerate(layers[:-1]):
        if len(layer.input_shape) == 2:
            # Dense Layer.
            if not flat:
                k = Flatten()(k)
                Y_c

        else:
            # Conv Layer.
            pass

        A_fixed, A_free = get_A(layer.output, k, epsilon)

        Y_c, Y_del = get_Y(Y_c, Y_del, A_fixed, A_free, W[i + 1])

        k = get_k(Y_c, Y_del)

    return k


def global_lipschitz_bound_orig(model):
    Ws = [W for W in model.weights if 'kernel' in W.name]
    layers = [layer for layer in model.layers if layer.get_weights()]

    grad_dim = np.prod(model.input_shape[1:])

    flat = False

    k = None
    for W, layer in zip(Ws, layers):
        if k is None:
            if len(K.int_shape(W)) == 2:
                # Dense Layer.
                k = K.abs(W)

                flat = True

            else:
                # Conv Layer.
                _, c_in, h_in, w_in = layer.input_shape
                _, c_out, h_out, w_out = layer.output_shape

                k = K.conv2d(K.reshape(K.eye(grad_dim),
                                       [grad_dim, c_in, h_in, w_in]),
                             K.abs(W),
                             padding=layer.padding,
                             strides=layer.strides)

        else:
            if len(K.int_shape(W)) == 2:
                # Dense Layer.
                if not flat:
                    k = K.reshape(k,
                                  (np.prod(grad_dim), c_out * h_out * w_out))

                k = k @ K.abs(W)

                flat = True

            else:
                # Conv Layer.
                _, c_out, h_out, w_out = layer.output_shape

                k = K.conv2d(k,
                             K.abs(W),
                             padding=layer.padding,
                             strides=layer.strides)

    return tf.norm(k, axis=0)[None]


def global_lipschitz_bound_fast(model):
    Ws = [W for W in model.weights if 'kernel' in W.name]
    layers = [layer for layer in model.layers if len(layer.weights) > 0]

    out_dim = model.output_shape[1]
    grad_dim = np.prod(model.input_shape[1:])

    unflattened = False

    k = None
    for W, layer in zip(Ws[::-1], layers[::-1]):
        if k is None:
            # The final layer is always a dense layer.
            k = K.transpose(K.abs(W))

        else:
            if len(K.int_shape(W)) == 2:
                # Dense Layer.
                k = k @ K.transpose(K.abs(W))

            else:
                # Conv Layer.
                _, c_in, h_in, w_in = layer.input_shape
                _, c_out, h_out, w_out = layer.output_shape

                if not unflattened:
                    k = K.reshape(k, (out_dim, c_out, h_out, w_out))
                    unflattened = True

                k = K.conv2d_transpose(k,
                                       K.abs(W),
                                       output_shape=(out_dim, c_in, h_in,
                                                     w_in),
                                       strides=layer.strides,
                                       padding=layer.padding)

    k = K.transpose(K.reshape(k, (out_dim, grad_dim)))

    return tf.norm(k, axis=0)[None]


def _SVD_Conv_Tensor(conv, inp_shape):
    """ 
    Find the singular values of the linear transformation corresponding to the 
    convolution represented by conv on an n x n x depth input. 
    Taken from the corresponding implementation of Hanie Sedghi, Vineet Gupta 
    and Philip M. Long. 'The Singular Values of Convolutional Layers'. ICLR 
    2019.

    URL: https://github.com/brain-research/conv-sv
    """
    conv_tr = tf.cast(tf.transpose(conv, perm=[2, 3, 0, 1]), tf.complex64)
    conv_shape = conv.get_shape().as_list()

    padding = tf.constant([[0, 0], [0, 0], [0, inp_shape[0] - conv_shape[0]],
                           [0, inp_shape[1] - conv_shape[1]]])

    transform_coeff = tf.signal.fft2d(tf.pad(conv_tr, padding))

    singular_values = tf.linalg.svd(tf.transpose(transform_coeff,
                                                 perm=[2, 3, 0, 1]),
                                    compute_uv=False)

    return singular_values


def l2_norm(input_x, epsilon=1e-12):
    """normalize input to unit norm"""
    input_x_norm = input_x / (tf.reduce_sum(input_x**2)**0.5 + epsilon)
    return input_x_norm


class PowerMethodRegularizer(tf.keras.regularizers.Regularizer):
    def __init__(self, strength=1., shape=None, strides=None, padding=None):
        self._strength = strength
        self._shape = shape
        self._strides = (strides, strides)
        self._padding = padding

    def __call__(self, w):
        if len(w.shape) == 4:
            x = tf.random.truncated_normal(shape=(1, ) + self._shape)
            x_p = K.conv2d(x, w, strides=self._strides, padding=self._padding)
            x = K.conv2d_transpose(x_p,
                                   w,
                                   x.shape,
                                   strides=self._strides,
                                   padding=self._padding)
            Wx1 = K.conv2d(x, w, strides=self._strides, padding=self._padding)

            x_p = K.conv2d(x, w, strides=self._strides, padding=self._padding)
            x = K.conv2d_transpose(x_p,
                                   w,
                                   x.shape,
                                   strides=self._strides,
                                   padding=self._padding)
            Wx2 = K.conv2d(x, w, strides=self._strides, padding=self._padding)

            k1 = K.sqrt(K.sum(K.pow(Wx1, 2.0)) / K.sum(K.pow(x, 2.0)))
            k2 = K.sqrt(K.sum(K.pow(Wx2, 2.0)) / K.sum(K.pow(x, 2.0)))

            return self._strength * K.square(k1 - k2)
        else:
            x = tf.random.truncated_normal(shape=(int(w.shape[1]), 1))
            x_p = K.dot(w, x)
            x = K.dot(K.transpose(w), x_p)
            k1 = K.sqrt(K.sum((w @ x)**2.) / K.sum(x**2.))

            x_p = K.dot(w, x)
            x = K.dot(K.transpose(w), x_p)
            k2 = K.sqrt(K.sum((w @ x)**2.) / K.sum(x**2.))

            return self._strength * K.square(k1 - k2)


def global_lipschitz_bound_spectral(model,
                                    use_svd='conv',
                                    num_iterations=5,
                                    warm_start_xs=None,
                                    do_final_layer=False,
                                    lowerbound_layerlip=None,
                                    norm='l2'):
    """
    Returns an upper bound of the global L2 lipschitz constant of a model by 
    calculating (or approximating) the spectral norm of each layer. This 
    implementation assumes that the constant for any layer other than `Dense` or
    `Conv2d` is 1.
    arguments:
        model: 
            a tf.keras.Model instance containing 2d convolutions and dense
            layers.
        use_svd: 
            string in ('conv', 'all', 'none'). If 'conv', then the exact method
            of [1] is used only on convolutional layers, and power iteration is
            used on dense (this is the default). If 'all', then the method of 
            [1] is used on conv layers, and svd is used on the dense layers. If
            'none', then power iteration is used on all layers, using the 
            approach described in [2] for convolutional layers.
        num_iterations: 
            an integer specifying the number of iterations to run the power 
            method for.
        warm_start_xs: 
            a dictionary of tensor variables to use as starting points for the
            power iteration method, mapped from their layer names.
    
    references:
        [1] Hanie Sedghi, Vineet Gupta and Philip M. Long. 'The Singular Values
            of Convolutional Layers'. ICLR 2019
        [2] Henry Gouk et al. 'Regularisation of Neural Networks by Enforcing 
            Lipschitz Continuity'. Maching Learning 2020
        [3] Bao Qi Feng. 'Equivalence constants for certain matrix norms'. Linear
            Algebra and its Applicaitons, 2002.
    """
    if num_iterations is None and (use_svd == 'conv' or use_svd == 'none'):
        raise RuntimeError('Must specify number of power method iterations')

    if warm_start_xs is None:
        xs = {}
    else:
        xs = warm_start_xs

    k_global = tf.constant(1.)
    updates = []
    do_layers = model.layers if do_final_layer else model.layers[:-1]
    input_dim = model.input.shape[1] * model.input.shape[2] * model.input.shape[3]
    res_id = 0
    k_r = tf.constant(1.)
    all_ks = []

    def lip_dense(w, layer, k, updates, xs, p='l2'):
        if p == 'l2':
            if use_svd == 'all':
                lip = tf.linalg.svd(w, compute_uv=False)[0]
                if lowerbound_layerlip is not None:
                    k *= lip + tf.constant(lowerbound_layerlip)
                else:
                    k *= lip
            else:
                if layer.name not in xs.keys():
                    x = tf.keras.backend.variable(tf.random.truncated_normal(
                                                    shape=(int(layer.kernel.shape[1]), 1)),
                                                name='{}_pk'.format(layer.name))
                    xs[layer.name] = x

                else:
                    x = xs[layer.name]

                for i in range(0, num_iterations):
                    x = x / tf.linalg.norm(tf.reshape(x, (-1, )))
                    x_p = K.dot(w, x)
                    x = K.dot(K.transpose(w), x_p)
                lip = K.sqrt(K.sum((w @ x)**2.) / K.sum(x**2.))
                if lowerbound_layerlip is not None:
                    k *= lip + tf.constant(lowerbound_layerlip)
                else:
                    k *= lip
                updates.append((xs[layer.name], x))
        elif p == 'linf':
            ub1 = K.sum(tf.norm(w, axis=1))
            ub2, updates, xs, _ = lip_dense(w, layer, tf.sqrt(tf.cast(w.shape[0], tf.float32)), updates, xs, p='l2')
            lip = K.min([ub1, ub2])
            if lowerbound_layerlip is not None:
                k *= lip + tf.constant(lowerbound_layerlip)
            else:
                k *= lip
            p = 'l2'
        else:
            raise ValueError(f"{p} is not a supported norm")
        all_ks.append(lip)
        return k, updates, xs, p

    def lip_conv(w, layer, k, updates, xs, p='l2'):
        if p == 'l2':
            if use_svd == 'conv' or use_svd == 'all':
                eig = tf.reduce_max(_SVD_Conv_Tensor(w, layer.input_shape[1:]))
                if type(layer.strides) is list:
                    eig /= layer.strides[0]
                elif type(layer.strides) is int:
                    eig /= float(layer.strides)
                elif type(layer.strides) is float:
                    eig /= layer.strides
                lip = eig
                if lowerbound_layerlip is not None:
                    k *= lip + tf.constant(lowerbound_layerlip)
                else:
                    k *= lip

            else:
                if layer.name not in xs.keys():
                    x = tf.keras.backend.variable(tf.random.truncated_normal(
                                                    shape=(1, ) + layer.input_shape[1:]),
                                                name='{}_pk'.format(layer.name))
                    xs[layer.name] = x
                else:
                    x = xs[layer.name]

                for i in range(0, num_iterations):
                    x = l2_norm(x)
                    x_p = K.conv2d(x,
                                w,
                                strides=layer.strides,
                                padding=layer.padding)
                    x = K.conv2d_transpose(x_p,
                                        w,
                                        x.shape,
                                        strides=layer.strides,
                                        padding=layer.padding)

                Wx = K.conv2d(x, w, strides=layer.strides, padding=layer.padding)
                lip = K.sqrt(K.sum(K.pow(Wx, 2.0)) / K.sum(K.pow(x, 2.0)))
                if lowerbound_layerlip is not None:
                    k *= lip + tf.constant(lowerbound_layerlip)
                else:
                    k *= lip
                updates.append((xs[layer.name], x))
        elif p =='linf':
            ub1 = K.sum(l2_norm_of_kernel(layer))
            ub2, updates, xs, _ = lip_conv(w, layer, tf.sqrt(tf.cast(input_dim, tf.float32)), updates, xs, p='l2')
            lip = K.min([ub1, ub2])
            if lowerbound_layerlip is not None:
                k *= lip + tf.constant(lowerbound_layerlip)
            else:
                k *= lip
            p = 'l2'
        else:
            raise ValueError(f"{p} is not a supported norm")
        all_ks.append(lip)
        return k, updates, xs, p

    for layer in do_layers:
        if hasattr(layer, 'kernel'):
            w = layer.kernel
            if not layer.name.startswith('r'):
                # Feed-forward layer
                if len(w.shape) == 4:
                    k_global, updates, xs, norm = lip_conv(w, layer, k_global,
                                                     updates, xs, p=norm)
                else:
                    k_global, updates, xs, norm = lip_dense(w, layer, k_global,
                                                      updates, xs, p=norm)
            else:
                # Residual Block
                if len(w.shape) == 4:
                    k_r, updates, xs, norm = lip_conv(w, layer, k_r, updates, xs, p=norm)
                else:
                    k_r, updates, xs, norm = lip_dense(w, layer, k_r, updates, p=norm)
                if 'end' in layer.name:  # The end of the current residual block
                    # Lip(skip_connection) = 1 + Lip(layers)
                    k_r += tf.constant(1.)
                    k_global *= k_r
                    k_r = tf.constant(1.)

    return k_global, updates, all_ks


def l2_normalize(x):
    return x / (K.sqrt(K.sum(x**2.)) + K.epsilon())


def global_lipschitz_bound_spectral_power(model,
                                          num_iterations,
                                          norm='l2',
                                          do_final_layer=False,
                                          lowerbound_layerlip=None):
    k_global = 1.
    k_r = 1.
    while_cond = lambda i, _: i < num_iterations
    do_layers = model.layers if do_final_layer else model.layers[:-1]

    def lip_dense(k, layer, W, norm):
        if norm == 'linf':
            print('::::::::::::; used linf')
            lip = K.sum(tf.norm(W, axis=1))
            # This gives us the Lipschitz constant w.r.t. the l2 norm of the
            # output. Thus, for future layers we can use the l2 norm.
            if lowerbound_layerlip is not None:
                k *= lip + tf.constant(lowerbound_layerlip)
            else:
                k *= lip
            norm = 'l2'
        elif norm == 'l2':
            x_0 = tf.random.truncated_normal(shape=(W.shape[1], 1))

            def body(i, x):
                x = l2_normalize(x)
                x_p = W @ x
                x = K.transpose(W) @ x_p
                return i + 1, x

            _, x = tf.while_loop(while_cond, body, [tf.constant(0), x_0])
            lip = K.sqrt(K.sum((W @ x)**2.) / K.sum(x**2.))

            if lowerbound_layerlip is not None:
                k *= lip + tf.constant(lowerbound_layerlip)
            else:
                k *= lip
        else:
            raise ValueError(f'{norm} norm not supported')

        return k, norm

    def lip_conv(k, layer, W, norm):
        # This is a convolutional layer.
        if norm == 'linf':
            lip = K.sum(l2_norm_of_kernel(layer))
            if lowerbound_layerlip is not None:
                k *= lip + tf.constant(lowerbound_layerlip)
            else:
                k *= lip
            # This gives us the Lipschitz constant w.r.t. the l2 norm of the
            # output. Thus, for future layers we can use the l2 norm.
            norm = 'l2'
        elif norm == 'l2':
            x_0 = tf.random.truncated_normal(shape=(1, *layer.input_shape[1:]))

            def body(i, x):
                x = l2_normalize(x)
                x_p = K.conv2d(x,
                               W,
                               strides=layer.strides,
                               padding=layer.padding)
                x = K.conv2d_transpose(x_p,
                                       W,
                                       x.shape,
                                       strides=layer.strides,
                                       padding=layer.padding)
                return i + 1, x

            _, x = tf.while_loop(while_cond, body, [tf.constant(0), x_0])
            Wx = K.conv2d(x, W, strides=layer.strides, padding=layer.padding)
            lip = K.sqrt(K.sum(Wx**2.) / K.sum(x**2.))

            if lowerbound_layerlip is not None:
                k *= lip + tf.constant(lowerbound_layerlip)
            else:
                k *= lip
        else:
            raise ValueError(f'{norm} norm not supported')
        return k, norm

    for layer in do_layers:
        if hasattr(layer, 'kernel'):
            W = layer.kernel
            if not layer.name.startswith('r'):
                # Feed-forward layer
                if len(W.shape) == 4:
                    k_global, norm = lip_conv(k_global, layer, W, norm)
                else:
                    k_global, norm = lip_dense(k_global, layer, W, norm)
            else:
                # Residual Block
                if len(W.shape) == 4:
                    k_r, norm = lip_conv(k_r, layer, W, norm)
                else:
                    k_r, norm = lip_dense(k_r, layer, W, norm)
                if 'end' in layer.name:  # The end of the current residual block
                    # Lip(skip_connection) = 1 + Lip(layers)
                    k_r += 1
                    k_global *= k_r
                    k_r = 1.

    return k_global


class SpectralStateUpdate(tf.keras.callbacks.Callback):
    def __init__(self,
                 updates,
                 xs,
                 asgns,
                 l_func,
                 all_ks_func,
                 spectral_tolerance,
                 batch_mod=200):
        self._upd_func = tf.keras.backend.function([], [tf.constant(0)],
                                                   updates)
        self._xs = xs
        self._asgns = asgns
        self._l_func = l_func
        self._all_ks_func = all_ks_func
        self._tol = spectral_tolerance
        self._batch_mod = batch_mod
        self._do_refresh = False

    def on_train_batch_end(self, batch, logs=None):
        self._upd_func([])

    def on_epoch_begin(self, epoch, logs=None):
        if self._do_refresh:
            xs = self._xs
            l_func = self._l_func
            for layer in self.model.layers:
                if not hasattr(layer, 'kernel'):
                    continue
                tf.compat.v1.keras.backend.get_session().run(
                    self._asgns[layer.name])
            k_c = l_func([])[0]
            k_l = np.infty
            print(k_c, end='', flush=True)
            while np.abs(k_c - k_l) >= self._tol:
                print('.', end='', flush=True)
                self._upd_func([])
                k_l = k_c
                k_c = l_func([])[0]
            print(k_c, end='\n')

    def on_test_begin(self, logs=None):
        l_func = self._l_func
        all_ks_func = self._all_ks_func
        k_c = l_func([])[0]
        k_l = np.infty
        all_ks = all_ks_func([])
        print(f'\n Layer-wise Lip: {all_ks}', end='', flush=True)
        print(f'\n Global Lip: {k_c}', end='', flush=True)
        while np.abs(k_c - k_l) >= self._tol:
            print('.', end='', flush=True)
            self._upd_func([])
            k_l = k_c
            k_c = l_func([])[0]
        print(k_c, end='\n')


def global_lipschitz_bound_linf(model,
                                use_svd='conv',
                                num_iterations=5,
                                warm_start_xs=None):
    """
    Returns an upper bound of the global L2 lipschitz constant of a model by 
    calculating (or approximating) the spectral norm of each layer. This 
    implementation assumes that the constant for any layer other than `Dense` or
    `Conv2d` is 1.

    TODO: The code currently works only if the first layer is a dense layer

    arguments:
        model: 
            a tf.keras.Model instance containing 2d convolutions and dense
            layers.
        use_svd: 
            string in ('conv', 'all', 'none'). If 'conv', then the exact method
            of [1] is used only on convolutional layers, and power iteration is
            used on dense (this is the default). If 'all', then the method of 
            [1] is used on conv layers, and svd is used on the dense layers. If
            'none', then power iteration is used on all layers, using the 
            approach described in [2] for convolutional layers.
        num_iterations: 
            an integer specifying the number of iterations to run the power 
            method for.
        warm_start_xs: 
            a dictionary of tensor variables to use as starting points for the
            power iteration method, mapped from their layer names.
    
    references:
        [1] Hanie Sedghi, Vineet Gupta and Philip M. Long. 'The Singular Values
            of Convolutional Layers'. ICLR 2019
        [2] Henry Gouk et al. 'Regularisation of Neural Networks by Enforcing 
            Lipschitz Continuity'. Maching Learning 2020
        [3] Bao Qi Feng. 'Equivalence constants for certain matrix norms'. Linear
            Algebra and its Applicaitons, 2002.
    """
    if num_iterations is None and (use_svd == 'conv' or use_svd == 'none'):
        raise RuntimeError('Must specify number of power method iterations')

    if warm_start_xs is None:
        xs = {}
    else:
        xs = warm_start_xs

    k = tf.constant(1.)
    is_first_layer = True
    for layer in model.layers:
        if not hasattr(layer, 'kernel'):
            continue

        w = layer.kernel

        # if is_first_layer:
        #     # k *= tf.reduce_sum(tf.norm(w, axis=0))
        #     k *= tf.sqrt(w.shape[1] * 1.0)
        #     is_first_layer = False

        if len(w.shape) == 4:
            if is_first_layer:
                out_shape = layer.output.shape().as_list()
                k *= K.sum(
                    l2_norm_of_kernel(layer))
                is_first_layer = False

            if use_svd == 'conv' or use_svd == 'all':
                eig = tf.reduce_max(_SVD_Conv_Tensor(w, layer.input_shape[1:]))
                if type(layer.strides) is list:
                    eig /= layer.strides[0]
                elif type(layer.strides) is int:
                    eig /= float(layer.strides)
                elif type(layer.strides) is float:
                    eig /= layer.strides
                k *= eig

            else:
                if layer.name not in xs.keys():
                    x = tf.Variable(tf.random.truncated_normal(
                        shape=(1, ) + layer.input_shape[1:]),
                                    trainable=False,
                                    name='{}_pk'.format(layer.name))
                    xs[layer.name] = x
                else:
                    x = xs[layer.name]

                for i in range(0, num_iterations):
                    x = l2_norm(x)
                    x_p = K.conv2d(x,
                                   w,
                                   strides=layer.strides,
                                   padding=layer.padding)
                    x = K.conv2d_transpose(x_p,
                                           w,
                                           x.shape,
                                           strides=layer.strides,
                                           padding=layer.padding)

                Wx = K.conv2d(x,
                              w,
                              strides=layer.strides,
                              padding=layer.padding)

                k *= K.sqrt(K.sum(K.pow(Wx, 2.0)) / K.sum(K.pow(x, 2.0)))

        else:
            if use_svd == 'all':
                layer_spectral_norm = tf.linalg.svd(w, compute_uv=False)[0]

            else:
                if layer.name not in xs.keys():
                    x = tf.Variable(tf.random.truncated_normal(
                        shape=(int(layer.kernel.shape[1]), 1)),
                                    trainable=False,
                                    name='{}_pk'.format(layer.name))
                    xs[layer.name] = x

                else:
                    x = xs[layer.name]

                for _ in range(0, num_iterations):
                    x = x / tf.linalg.norm(tf.reshape(x, (-1, )))
                    x_p = K.dot(w, x)
                    x = K.dot(K.transpose(w), x_p)

                layer_spectral_norm = K.sqrt(K.sum((w @ x)**2.) / K.sum(x**2.))

            if is_first_layer:
                ub1 = K.sum(
                    tf.linalg.norm(w, axis=1)
                )  # ||W||_inf_2 <= |W|_2_1. Use axis=1 since W is input_dim x output_dim
                ub2 = layer_spectral_norm * tf.sqrt(
                    w.shape[0] * 1.0)  # ||W||_inf_2 <= sqrt(n)||W||_2

                k *= K.min([ub1, ub2])  # use the tighter one
                is_first_layer = False
            else:
                k *= layer_spectral_norm

    return k


global_lipschitz_bound = global_lipschitz_bound_fast


class LipschitzMargin(Layer):
    def __init__(self, epsilon, **kwargs):
        super().__init__(**kwargs)

        self._epsilon = tf.Variable(epsilon)

        self.trainable = False

    @property
    def epsilon(self):
        return K.get_value(self._epsilon)

    @epsilon.setter
    def epsilon(self, new_eps):
        K.set_value(self._epsilon, new_eps)

    def call(self, y, k):
        max_mask = tf.cast(tf.equal(y, K.max(y, axis=1, keepdims=True)),
                           'float32')

        k_c = K.sum(max_mask * k, axis=1)[:, None]
        k_others = (1. - max_mask) * k

        others = (1. - max_mask) * y + (max_mask * K.min(y, axis=1)[:, None])

        worst_case = K.max(others + self._epsilon * (k_others + k_c),
                           axis=1)[:, None]

        return K.concatenate((y, worst_case), axis=1)

    def get_config(self):
        return {'epsilon': self.epsilon}


class SpectralMargin(Layer):
    def __init__(self, epsilon, final_weights, **kwargs):
        super().__init__(**kwargs)

        self._epsilon = tf.Variable(epsilon)
        self._w = final_weights
        self.trainable = False

    @property
    def epsilon(self):
        return K.get_value(self._epsilon)

    @epsilon.setter
    def epsilon(self, new_eps):
        K.set_value(self._epsilon, new_eps)

    def call(self, y, k):

        preds = tf.argmax(y, axis=1)
        w_norm = tf.linalg.norm(self._w, axis=0, keepdims=True)
        w_top = tf.gather(tf.transpose(self._w), preds)
        w_diff = w_top[:, :, None] - self._w[None]
        # y_diff should get the margin between the top two classes
        # always >= 0
        y_diff = tf.reduce_max(y, axis=1, keepdims=True) - y
        w_diff_norm = tf.linalg.norm(w_diff, axis=1)
        w_diff_norm = tf.sqrt(tf.reduce_sum(w_diff * w_diff, axis=1) + 1.e-10)
        # margin_k will have a negative component wherever there is a possible violation
        margin_k = y_diff - self._epsilon * k * w_diff_norm
        margin_k = tf.where(
            tf.equal(y, tf.reduce_max(y, axis=1, keepdims=True)),
            np.infty + tf.zeros_like(margin_k), margin_k)

        new_logit = tf.reduce_max(y, axis=1, keepdims=True) - tf.reduce_min(
            margin_k, axis=1, keepdims=True)

        return tf.concat([y, new_logit], axis=1)

    def get_config(self):
        return {'epsilon': self.epsilon}


class SpectralMargin_Root2(Layer):
    def __init__(self, epsilon, **kwargs):
        super().__init__(**kwargs)

        self._epsilon = tf.Variable(epsilon)
        self.trainable = False

    @property
    def epsilon(self):
        return K.get_value(self._epsilon)

    @epsilon.setter
    def epsilon(self, new_eps):
        K.set_value(self._epsilon, new_eps)

    def call(self, y, k):

        new_logit = (tf.expand_dims(tf.math.top_k(y, 2).values[:, 1], 1) +
                     tf.sqrt(2.0) * self._epsilon * k)

        return tf.concat([y, new_logit], axis=1)

    def get_config(self):
        return {'epsilon': self.epsilon}


class ConstantSpectralMargin(Layer):
    def __init__(self, epsilon, k, final_weights, **kwargs):
        super().__init__(**kwargs)

        self._epsilon = tf.Variable(epsilon)
        self._w = tf.Variable(final_weights)
        self._k = tf.Variable(k)
        self.trainable = False

    @property
    def epsilon(self):
        return K.get_value(self._epsilon)

    @epsilon.setter
    def epsilon(self, new_eps):
        K.set_value(self._epsilon, new_eps)

    @property
    def final_weights(self):
        return K.get_value(self._w)

    @final_weights.setter
    def w(self, new_w):
        K.set_value(self._w, new_w)

    @property
    def k(self):
        return K.get_value(self._k)

    @k.setter
    def k(self, new_k):
        K.set_value(self._k, new_k)

    def call(self, y):

        k = self._k

        preds = tf.argmax(y, axis=1)
        w_norm = tf.linalg.norm(self._w, axis=0, keepdims=True)
        w_top = tf.gather(tf.transpose(self._w), preds)
        w_diff = w_top[:, :, None] - self._w[None]
        # y_diff should get the margin between the top two classes
        # always >= 0
        y_diff = tf.reduce_max(y, axis=1, keepdims=True) - y
        w_diff_norm = tf.linalg.norm(w_diff, axis=1)
        w_diff_norm = tf.sqrt(tf.reduce_sum(w_diff * w_diff, axis=1) + 1.e-10)
        # margin_k will have a negative component wherever there is a possible violation
        margin_k = y_diff - self._epsilon * k * w_diff_norm
        margin_k = tf.where(
            tf.equal(y, tf.reduce_max(y, axis=1, keepdims=True)),
            np.infty + tf.zeros_like(margin_k), margin_k)

        new_logit = tf.reduce_max(y, axis=1, keepdims=True) - tf.reduce_min(
            margin_k, axis=1, keepdims=True)

        return tf.concat([y, new_logit], axis=1)

    def get_config(self):
        return {'epsilon': self.epsilon, 'k': self.k, 'final_weights': self.w}


class ConstantSpectralMargin_Root2(Layer):
    def __init__(self, epsilon, k, **kwargs):
        super().__init__(**kwargs)

        self._epsilon = tf.Variable(epsilon)
        self.trainable = False
        self._k = tf.Variable(k)

    @property
    def epsilon(self):
        return K.get_value(self._epsilon)

    @epsilon.setter
    def epsilon(self, new_eps):
        K.set_value(self._epsilon, new_eps)

    @property
    def k(self):
        return K.get_value(self._k)

    @k.setter
    def k(self, new_k):
        K.set_value(self._k, new_k)

    def call(self, y):

        new_logit = (tf.expand_dims(tf.math.top_k(y, 2).values[:, 1], 1) +
                     tf.sqrt(2.0) * self._epsilon * self._k)

        return tf.concat([y, new_logit], axis=1)

    def get_config(self):
        return {'epsilon': self.epsilon, 'k': self.k}


def fl(layers, eps):
    if len(layers) == 1:
        layer = layers[0]

        z = layer.output

        W_norm = l2_norm_of_kernel_axis0(
            layer.weights[0],
            padding=layer.padding,
            strides=layer.strides[0],
            #    h_in=layer.input_shape[1],
            #    w_in=layer.input_shape[2],
            h_out=layer.output_shape[1],
            w_out=layer.output_shape[2])[None]

        u = z + eps * W_norm
        l = z - eps * W_norm

        return l, u

    l, u = fl(layers[:-1], eps)

    layer = layers[-1]

    W = layer.weights[0]
    b = layer.weights[1]

    def forward(W, Z):
        if len(K.int_shape(W)) == 4:
            # This is a convolution.
            return K.conv2d(Z, W, strides=layer.strides, padding=layer.padding)

        else:
            # This is a dense layer.
            if len(K.int_shape(Z)) == 4:
                # We need to flatten.
                Z = Flatten()(Z)

            return Z @ W

    u2 = b + forward(K.relu(W), K.relu(u)) - forward(K.relu(-W), K.relu(l))
    l2 = b + forward(K.relu(W), K.relu(l)) - forward(K.relu(-W), K.relu(u))

    return l2, u2


def fastlip(layers, eps):

    # Get the upper and lower bounds on the neurons.
    L, U = [], []

    for i, layer in enumerate(layers):
        if i == 0:
            z = layer.output

            W_norm = l2_norm_of_kernel_axis0(
                layer.weights[0],
                padding=layer.padding,
                strides=layer.strides[0],
                #    h_in=layer.input_shape[1],
                #    w_in=layer.input_shape[2],
                h_out=layer.output_shape[1],
                w_out=layer.output_shape[2])[None]

            U.append(z + eps * W_norm)
            L.append(z - eps * W_norm)

        else:
            W = layer.weights[0]
            b = layer.weights[1]

            def forward(W, Z):
                if len(K.int_shape(W)) == 4:
                    # This is a convolution.
                    return K.conv2d(Z,
                                    W,
                                    strides=layer.strides,
                                    padding=layer.padding)

                else:
                    # This is a dense layer.
                    if len(K.int_shape(Z)) == 4:
                        # We need to flatten.
                        Z = Flatten()(Z)

                    return Z @ W

            U.append(b + forward(K.relu(W), K.relu(U[i - 1])) -
                     forward(K.relu(-W), K.relu(L[i - 1])))
            L.append(b + forward(K.relu(W), K.relu(L[i - 1])) -
                     forward(K.relu(-W), K.relu(U[i - 1])))

    # In reverse order, multiply the weights.
    for i, layer in list(enumerate(layers))[::-1]:
        W = layer.weights[0]

        if i == len(layers) - 1:
            Y_c = K.transpose(W)[None]  # n_m x n_m-1 -> ? x n_m x n_m-1
            Y_d = 0.

        else:

            def backward(W, Y):
                if len(K.int_shape(W)) == 4:
                    # This is a convolution.
                    _, h_in, w_in, c_in = layer.input_shape
                    _, h_out, w_out, c_out = layer.output_shape

                    batch = Y.shape[0]
                    n_m = K.int_shape(Y)[1]

                    Y = K.reshape(Y, (-1, h_out, w_out, c_out))

                    Y = K.conv2d_transpose(Y,
                                           K.abs(W),
                                           output_shape=(None, h_in, w_in,
                                                         c_in),
                                           strides=layer.strides,
                                           padding=layer.padding)
                    # print(Y)

                    return K.reshape(Y, (-1, n_m, h_in, w_in, c_in))

                else:
                    # This is a dense layer.
                    return Y @ K.transpose(W)[None]

            A_fixed = tf.cast(L[i] > 0, 'float32')
            A_free = tf.cast(L[i] < 0, 'float32') * tf.cast(
                U[i] > 0, 'float32')

            A_fixed = K.reshape(A_fixed, (-1, 1, *K.int_shape(Y_c)[2:]))
            A_free = K.reshape(A_free, (-1, 1, *K.int_shape(Y_c)[2:]))

            if Y_d == 0.:
                # A_fx : (?, n_i+1) or (?, h_i+1, w_i+1, c_i+1)
                # W : (n_i,  n_i+1) or (f, f, n_i, n_i+1)
                # Y : (?, n_m, n_i+1) or (?, n_m, h_i+1, w_i+1, c_i+1)
                # Y' : (?, n_m, n_i) or (?, n_m, h_i, w_i, c_i)

                Y2_c = backward(W, Y_c * A_fixed)
                Y2_d = backward(K.abs(W), K.abs(Y_c) * A_free)

            else:
                Y2_c = backward(W, Y_c * A_fixed)
                Y2_d = (backward(K.abs(W),
                                 K.abs(Y_d) * A_fixed) +
                        backward(K.abs(W), (K.abs(Y_c) + K.abs(Y_d)) * A_free))

            Y_c = Y2_c
            Y_d = Y2_d

    max_grad = K.maximum(K.abs(Y_c + Y_d), K.abs(Y_c - Y_d))

    out_dim = layers[-1].output_shape[1]
    grad_dim = np.prod(layers[0].input_shape[1:])

    max_grad = K.permute_dimensions(
        K.reshape(max_grad, (-1, out_dim, grad_dim)), (0, 2, 1))

    return tf.norm(max_grad, axis=1)


class FlMargin(Layer):
    def __init__(self, epsilon, **kwargs):
        super().__init__(**kwargs)

        self.epsilon = epsilon

    def call(self, y, l, u):
        y_c = K.max(y, axis=1, keepdims=True)

        max_mask = tf.cast(tf.equal(y, y_c), 'float32')

        l_c = K.sum(max_mask * l, axis=1, keepdims=True)

        u_j = K.max(
            (1 - max_mask) * u + max_mask * K.min(l, axis=1, keepdims=True),
            axis=1,
            keepdims=True)

        return K.concatenate((y, y_c - l_c + u_j), axis=1)

    def get_config(self):
        return {'epsilon': self.epsilon}


def add_extra_column(y):
    return np.hstack((y, np.zeros((len(y), 1))))


def ResnetBlock_NBN(input_tensor,
                    kernel_size,
                    filters,
                    id,
                    use_power_reg=False,
                    input_shape=None):
    filters1, filters2, filters3 = filters
    if use_power_reg and input_shape is not None:
        out = tf.keras.layers.Conv2D(filters1, (1, 1),
                                     name='r' + str(id) + '_conv1',
                                     kernel_regularizer=PowerMethodRegularizer(
                                         strength=1,
                                         shape=input_shape,
                                         padding='valid',
                                         strides=(1, 1)))(input_tensor)
        out = Activation('relu')(out)
        out = tf.keras.layers.Conv2D(filters2,
                                     kernel_size,
                                     padding='same',
                                     name='r' + str(id) + '_conv2',
                                     kernel_regularizer=PowerMethodRegularizer(
                                         strength=1,
                                         shape=input_shape[:-1] + [filters1],
                                         padding='same',
                                         strides=(1, 1)))(out)
        out = Activation('relu')(out)
        out = tf.keras.layers.Conv2D(filters3, (1, 1),
                                     name='r' + str(id) + '_conv_end',
                                     kernel_regularizer=PowerMethodRegularizer(
                                         strength=1,
                                         shape=input_shape[:-1] + [filters2],
                                         padding='valid',
                                         strides=(1, 1)))(out)
    else:
        out = tf.keras.layers.Conv2D(filters1, (1, 1),
                                     name='r' + str(id) +
                                     '_conv1')(input_tensor)
        out = Activation('relu')(out)
        out = tf.keras.layers.Conv2D(filters2,
                                     kernel_size,
                                     padding='same',
                                     name='r' + str(id) + '_conv2')(out)
        out = Activation('relu')(out)
        out = tf.keras.layers.Conv2D(filters3, (1, 1),
                                     name='r' + str(id) + '_conv_end')(out)
    out += input_tensor
    return Activation('relu')(out)


if __name__ == '__main__':

    import tensorflow as tf

    gpus = tf.config.experimental.list_physical_devices('GPU')
    tf.config.experimental.set_visible_devices(gpus[2], 'GPU')

    for device in tf.config.experimental.get_visible_devices('GPU'):
        print(device)
        tf.config.experimental.set_memory_growth(device, True)

    import numpy as np

    from scriptify import scriptify

    from tensorflow.keras.layers import Activation
    from tensorflow.keras.layers import Conv2D
    from tensorflow.keras.layers import Dense
    from tensorflow.keras.layers import Flatten
    from tensorflow.keras.layers import Input
    from tensorflow.keras.models import Model
    from time import time

    @scriptify
    def test_lipschitz_bounds(layers=3,
                              width=10,
                              inputs=3,
                              classes=3,
                              epsilon=0.5,
                              samples=10000,
                              conv=False):
        '''
        Make sure that the Lipschitz bounds hold for randomly-generated points.
        '''
        if conv:
            x = Input((inputs, 10, 10))
            z = x

            for _ in range(layers):
                z = Conv2D(width,
                           3,
                           padding='same',
                           activation='linear',
                           bias_initializer='random_uniform')(z)
                z = Activation('relu')(z)

            z = Flatten()(z)

        else:
            x = Input((inputs, ))
            z = x

            for _ in range(layers):
                z = Dense(width, bias_initializer='random_uniform')(z)
                z = Activation('relu')(z)

        y = Dense(classes)(z)

        f = Model(x, y)

        f.summary()

        lip_glob = global_lipschitz_bound_orig(f)
        lip_glob_fast = global_lipschitz_bound(f)
        lip_loc = fastlip([l for l in f.layers if l.get_weights()], epsilon)
        lip_spect = global_lipschitz_bound_spectral(f, use_svd='all')

        lip_glob_model = Model(x, lip_glob)
        lip_glob_fast_model = Model(x, lip_glob_fast)
        lip_loc_model = Model(x, lip_loc)
        lip_spect_model = Model(x,
                                lip_spect * K.ones_like(x)[:, None, 0, 0, 0])

        if conv:
            X = (np.random.rand(samples, inputs, 10, 10) - 0.5) * 2
        else:
            X = (np.random.rand(samples, inputs) - 0.5) * 2

        # Pick a random point at distance epsilon from each sample and make sure
        # that the Lipschitz bound holds.
        if conv:
            delta = np.random.rand(samples, inputs * 10 * 10) - 0.5
        else:
            delta = np.random.rand(samples, inputs) - 0.5
        delta = epsilon * delta / np.linalg.norm(delta, axis=1, keepdims=True)
        if conv:
            delta = delta.reshape(samples, inputs, 10, 10)

        y1 = f.predict(X)
        y2 = f.predict(X + delta)

        empirical_k = abs(y1 - y2) / epsilon

        empirical_k_l2 = (np.linalg.norm(y1 - y2, axis=1, keepdims=True) /
                          epsilon)

        t0 = time()
        k_glob = lip_glob_model.predict(X)
        t1 = time()
        k_glob_fast = lip_glob_fast_model.predict(X)
        t2 = time()
        k_loc = lip_loc_model.predict(X)
        t3 = time()
        k_spect = lip_spect_model.predict(X)
        t4 = time()

        print(f'\nTime for Global:       {t1 - t0} s')
        print(f'\nTime for Global Fast:  {t2 - t1} s')
        print(f'\nTime for Local:        {t3 - t2} s')
        print(f'\nTime for Spectral SVD: {t4 - t3} s')

        def check(empirical_k, k):
            failures = empirical_k > k

            print(
                f'Bound was respected in {(1. - np.mean(failures)) * 100}% of '
                f'samples (out of {samples}).\n')

            if np.sum(failures) > 0:
                print(
                    f'> failed; showing '
                    f'{min(10, failures.sum())} / {failures.sum()} failures:\n'
                )

                for ek_i, k_i in zip(empirical_k[failures][:10],
                                     k[failures][:10]):

                    print(f'got K = {ek_i}, expected to be less than {k_i}')

        print('\nGlobal Lipschitz Bound\n' + '-' * 80)
        check(empirical_k, k_glob)

        print('\nGlobal Lipschitz Bound Fast\n' + '-' * 80)
        check(empirical_k, k_glob_fast)

        print(f'Average ratio of global to empirical: '
              f'{np.mean(k_glob_fast / empirical_k):.3f}\n')

        print('\nFast Global Lipschitz Bound Same as Original\n' + '-' * 80)
        print(np.allclose(k_glob_fast / k_glob, np.ones_like(k_glob)))

        print('\nLocal Lipschitz Bound\n' + '-' * 80)
        check(empirical_k, k_loc)

        print('\nLocal Lipschitz Bound Less Than Global Bound\n' + '-' * 80)
        print(f'Average ratio of local to global: '
              f'{np.mean(k_loc / k_glob):.3f}\n')
        check(k_loc, k_glob + 1e-5)

        print('\nGlobal Lipschitz Bound Spectral Norm (SVD)\n' + '-' * 80)
        check(empirical_k_l2, k_spect)

        print(f'Average ratio of spectral to empirical: '
              f'{np.mean(k_spect / empirical_k_l2):.3f}\n')

        print(f'Average ratio of spectral to global: '
              f'{np.mean(k_spect * np.sqrt(2) / 2 / k_glob):.3f}\n')
