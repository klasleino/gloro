import numpy as np
import tensorflow as tf

from scipy.stats import truncnorm
from tensorflow.keras import backend as K
from tensorflow.keras.layers import Layer
from tensorflow.keras.models import Model


def l2_norm_of_kernel(layer):
    
    W = layer.kernel

    padding = layer.padding
    strides = layer.strides[0]

    # Currently we only support strides of 1.
    if strides > 1:
        raise ValueError('strides greater than 1 not supported')

    # For channels LAST.
    _, h_in, w_in, c_in = layer.input_shape
    _, h_out, w_out, c_out = layer.output_shape

    kernel_size = K.int_shape(W)[0]

    padding_start = int(np.ceil((kernel_size - 1) / strides)) // 2
    padding_end = int(np.ceil((kernel_size - 1) / strides)) - padding_start

    kernel = W

    # Obnoxiously, `conv2d_transpose` requires us to specify the output shape,
    # even though this should be calculated based on the kernel size, strides,
    # etc. To avoid having to recreate that logic, we'll just use a 
    # `Conv2DTranspose` layer, which calculates the output shape for us.
    l = tf.keras.layers.Conv2DTranspose(
        1, kernel_size, dilation_rate=strides, padding=padding)
    expected_output_shape = K.int_shape(l(
        np.ones((c_in, kernel_size, kernel_size, c_out), dtype=np.float32)))

    template = K.sqrt(
        K.conv2d_transpose(
            K.permute_dimensions(kernel, (2, 0, 1, 3))**2,
            np.ones((kernel_size, kernel_size, 1, c_out), dtype=np.float32),
            output_shape=expected_output_shape,
            strides=(1,1),
            dilation_rate=(strides,strides),
            padding=padding))

    padding_start += (expected_output_shape[1] - kernel_size) // 2
    padding_end += (expected_output_shape[1] - kernel_size) // 2

    padding_array_h = (
        [1 for _ in range(padding_start)] +
        [h_in - padding_start - padding_end] +
        [1 for _ in range(padding_end)])
    padding_array_w = (
        [1 for _ in range(padding_start)] +
        [w_in - padding_start - padding_end] +
        [1 for _ in range(padding_end)])

    template = tf.repeat(
        tf.repeat(template, padding_array_h, axis=1),
        padding_array_w,
        axis=2)

    return K.permute_dimensions(template[:, :, :, 0], (1, 2, 0))


def l2_norm_of_kernel_axis0(layer):
    
    W = layer.kernel

    padding = layer.padding
    strides = layer.strides[0]

    # For channels LAST.
    _, h_in, w_in, c_in = layer.input_shape
    _, h_out, w_out, c_out = layer.output_shape

    kernel_size = K.int_shape(W)[0]

    padding_start = int(np.ceil((kernel_size - 1) / strides)) // 2
    padding_end = int(np.ceil((kernel_size - 1) / strides)) - padding_start

    kernel = tf.pad(W, [
        [padding_end, padding_start],
        [padding_end, padding_start],
        [0, 0],
        [0, 0],
    ]) if padding == 'same' else W

    template = K.sqrt(
        K.conv2d(
            K.permute_dimensions(kernel, (3, 0, 1, 2))**2,
            np.ones((kernel_size, kernel_size, c_in, 1), dtype=np.float32),
            strides=1,
            padding='valid'))

    # Need to rotate.
    template = tf.image.rot90(template, 2)

    print(K.int_shape(template))

    if padding == 'valid':
        padding_array_h = [h_out]
        padding_array_w = [w_out]

    elif padding == 'same':
        padding_array_h = (
            [1 for _ in range(padding_start)] +
            [h_out - padding_start - padding_end] +
            [1 for _ in range(padding_end)])
        padding_array_w = (
            [1 for _ in range(padding_start)] +
            [w_out - padding_start - padding_end] +
            [1 for _ in range(padding_end)])

    template = tf.repeat(
        tf.repeat(template, padding_array_h, axis=1),
        padding_array_w,
        axis=2)

    return K.permute_dimensions(template[:, :, :, 0], (1, 2, 0))


def l2_normalize(x):
    return x / (K.sqrt(K.sum(x**2.)) + K.epsilon())


def np_truncated_normal(shape):
    return truncnorm.rvs(-2., 2., size=shape).astype('float32')


def global_lipschitz_bound_spectral_power(
        model, 
        num_iterations, 
        norm='l2', 
        exclude_last_layer=False, 
        maintain_state=False):

    k = 1.

    while_cond = lambda i, _: i < num_iterations

    layers = model.layers[:-1] if exclude_last_layer else model.layers

    # Used if we're maintaining the iterates' states.
    iterates = []
    updates = []

    for layer in layers:
        if not hasattr(layer, 'kernel'):
            continue

        W = layer.kernel

        if len(W.shape) == 4:
            # This is a convolutional layer.
            if norm == 'linf':
                k *= K.sum(l2_norm_of_kernel(layer))

                # This gives us the Lipschitz constant w.r.t. the l2 norm of the
                # output. Thus, for future layers we can use the l2 norm.
                norm = 'l2'

            elif norm == 'l2':
                if maintain_state:
                    x_0 = tf.Variable(
                        np_truncated_normal((1,*layer.input_shape[1:])),
                        trainable=False)

                    iterates.append(x_0)

                else:
                    x_0 = tf.random.truncated_normal(
                        shape=(1,*layer.input_shape[1:]))

                def body(i, x):
                    x = l2_normalize(x)

                    x_p = K.conv2d(
                        x,
                        W,
                        strides=layer.strides,
                        padding=layer.padding)
                    x = K.conv2d_transpose(
                        x_p,
                        W,
                        x.shape,
                        strides=layer.strides,
                        padding=layer.padding)

                    return i + 1, x

                _, x = tf.while_loop(while_cond, body, [tf.constant(0), x_0])

                if maintain_state:
                    updates.append((x_0, x))

                Wx = K.conv2d(
                    x, W, strides=layer.strides, padding=layer.padding)

                k *= K.sqrt(K.sum(Wx**2.) / K.sum(x**2.))

            else:
                raise ValueError(f'{norm} norm not supported')

        else:
            if norm == 'linf':
                k *= K.sum(tf.norm(W, axis=1))

                # This gives us the Lipschitz constant w.r.t. the l2 norm of the
                # output. Thus, for future layers we can use the l2 norm.
                norm = 'l2'

            elif norm == 'l2':
                if maintain_state:
                    x_0 = tf.Variable(
                        np_truncated_normal((W.shape[1], 1)),
                        trainable=False)

                    iterates.append(x_0)

                else:
                    x_0 = tf.random.truncated_normal(shape=(W.shape[1], 1))

                def body(i, x):
                    x = l2_normalize(x)
                    x_p = W @ x
                    x = K.transpose(W) @ x_p

                    return i + 1, x

                _, x = tf.while_loop(while_cond, body, [tf.constant(0), x_0])

                if maintain_state:
                    updates.append((x_0, x))

                k *= K.sqrt(K.sum((W @ x)**2.) / K.sum(x**2.))

            else:
                raise ValueError(f'{norm} norm not supported')

    if maintain_state:
        return k, iterates, updates

    return k


class SpectralNormViaPowerMethod(Layer):
    def __init__(
            self, 
            model, 
            num_iterations=5, 
            norm='l2', 
            use_operator_norm=True,
            hardcoded_k=None, 
            maintain_state=False,
            **kwargs):
        super().__init__(**kwargs)

        self._num_iterations = tf.Variable(num_iterations, trainable=False)
        self._norm = norm
        self._maintain_state = maintain_state

        if hardcoded_k is None:
            k = global_lipschitz_bound_spectral_power(
                model, 
                self._num_iterations, 
                norm, 
                exclude_last_layer=not use_operator_norm,
                maintain_state=maintain_state)

            if maintain_state:
                k, iterates, updates = k

                self._iterates = iterates
                self._update_fun = K.function([], [k], updates=updates)

            self._pre_k = k

            if not use_operator_norm:
                k = k * model.layers[-1].kernel

        else:
            assert model is None

            k = tf.constant(hardcoded_k)

        self._k = k

    @property
    def num_iterations(self):
        return K.get_value(self._num_iterations)

    @num_iterations.setter
    def num_iterations(self, new_num_iterations):
        K.set_value(self._num_iterations, new_num_iterations)

    @property
    def lipschitz_constant(self):
        return K.get_value(self._k)

    @property
    def _lipschitz_constant(self):
        return K.get_value(self._pre_k)

    @property
    def non_trainable_weights(self):
        return [self._num_iterations]

    def refresh_iterates(
            self, 
            converge=True, 
            convergence_threshold=1e-5, 
            max_tries=200, 
            batch_size=None):

        if not self._maintain_state:
            return self

        for iterate in self._iterates:
            K.set_value(iterate, np_truncated_normal(K.int_shape(iterate)))

        if converge:
            if batch_size:
                old_num_iterations = self.num_iterations
                self.num_iterations = batch_size

            i = 0
            k_prev = None
            k = self._update_fun([])[0]

            while i < max_tries and (
                    k_prev is None or abs(k - k_prev) > convergence_threshold):

                k_prev = k
                k = self._update_fun([])[0]
                i += 1

            if batch_size:
                self.num_iterations = old_num_iterations

            print(f'  power method converged in {i+1} iterations')

        return self

    def update_iterates(self):
        if not self._maintain_state:
            return self

        self._update_fun([])

        return self

    def call(self, _):
        return self._k

    def get_config(self):
        return {
            'model': None,
            'num_iterations': self.num_iterations,
            'norm': self._norm,
            'hardcoded_k': self.lipschitz_constant,
            'name': self.name,
        }
        

class LipschitzMargin(Layer):
    def __init__(self, epsilon, use_operator_norm=True, **kwargs):
        super().__init__(**kwargs)

        self._epsilon = tf.Variable(epsilon, trainable=False)

        self._use_operator_norm = use_operator_norm

    @property
    def epsilon(self):
        return K.get_value(self._epsilon)

    @epsilon.setter
    def epsilon(self, new_epsilon):
        K.set_value(self._epsilon, new_epsilon)

    def call(self, yk):
        y, k = yk

        if self._use_operator_norm:
            # This Lipschitz constant represents the operator norm of the 
            # network, i.e., the largest l2 distance between `y` and any ouput
            # generated from an input within the epsilon ball.
            new_logit = (
                tf.math.top_k(y, 2).values[:, 1, None] + 
                tf.sqrt(2.0) * self._epsilon * k)

        else:
            # This is the operator norm of the penultimate layer of the network
            # multiplied by the weights of the penulimate layer. We want to 
            # compute the Lipschitz constant for the margin of the predicted 
            # class over the other classes.
            kW = k

            c = K.argmax(y, axis=1)
            y_c = K.max(y, axis=1, keepdims=True)
            where_not_c = tf.not_equal(y, y_c)

            # Get the weight column of the predicted class.
            kW_c = tf.gather(K.transpose(kW), c)

            # Get the margin the top class has above each other class.
            y_d = y_c - y

            # Get weights that predict the value y_c - y_j for all j != c.
            kW_d = kW_c[:,:,None] - kW[None]
            
            # We do this instead of tf.linalg.norm(W_d) because of an
            # apparent bug in tf.linalg.norm that leads to NaN values.
            kW_d_norm = K.sqrt(K.sum(kW_d * kW_d, axis=1) + 1.e-10)

            # This gives the lower bound on the size of the margin after a
            # perturbation of epsilon. If this is negative, then an adversarial
            # example may exist.
            margin_bound = y_d - self._epsilon * kW_d_norm

            # The margin bound will be zero at the position of class c. However,
            # we don't want to consider this class, so we replace the zero with
            # infinity so that when we find the minimum lower bound we don't get
            # zero as a result of all of the bounds we care aobut being 
            # positive.
            margin_bound = tf.where(
                tf.equal(y, y_c), 
                np.infty + tf.zeros_like(margin_bound), 
                margin_bound)

            new_logit = y_c - K.min(margin_bound, axis=1, keepdims=True)

        return tf.concat([y, new_logit], axis=1)

    def get_config(self):
        return {
            'epsilon': self.epsilon, 
            'use_operator_norm': self._use_operator_norm
        }


def instrument_with_spectral_norm_margin(
        model, 
        epsilon, 
        num_iterations=5, 
        norm='l2', 
        use_operator_norm=False,
        maintain_state=False):

    x = model.input
    y = model.output

    k = SpectralNormViaPowerMethod(
        model, 
        num_iterations, 
        norm, 
        name='spectral_norm', 
        use_operator_norm=use_operator_norm,
        maintain_state=maintain_state)(y)

    margin = LipschitzMargin(
        epsilon, use_operator_norm=use_operator_norm)([y, k])

    return Model(x, margin)


################################################################################
# TESTS
################################################################################


def _sanity_check_spectoral_lipschitz_constant_dense(
        samples=10000,
        norm='l2',
        layers=3,
        width=32,
        inputs=3, 
        classes=3):

    x = Input((inputs,))

    z = x
    for _ in range(layers):
        z = Dense(width)(z)
        z = Activation('relu')(z)

    y = Dense(classes)(z)

    f = Model(x, y)

    k = SpectralNormViaPowerMethod(
        f, 100, norm, name='spectral_norm').lipschitz_constant

    X = (np.random.rand(samples, inputs) - 0.5) * 2

    delta = np.random.rand(samples, inputs) - 0.5
    if norm == 'l2':
        delta = delta / np.linalg.norm(delta, axis=1, keepdims=True)
    elif norm == 'linf':
        delta = delta / np.linalg.norm(delta, ord=np.inf, axis=1, keepdims=True)
    else:
        raise ValueError(f'{norm} norm not supported')

    y1 = f.predict(X)
    y2 = f.predict(X + delta)

    empirical_k = np.linalg.norm(y1 - y2, axis=1)

    success_rate = np.mean(empirical_k <= k)

    print('')
    print('-'*80)
    print(f'Sanity-checking dense Lipschitz bound with {norm} norm')
    print('-'*80)
    print(
        f'Empirical Lipschitz constant was smaller in {success_rate*100:.1f}% '
        f'of cases')
    print('\nSuccess!' if success_rate == 1. else '\nFailure.')

    if success_rate < 1.:
        for ek_i in empirical_k[empirical_k > k][:10]:
            print(f'>>>> {k} was less than {ek_i}')

    return success_rate == 1.


def _sanity_check_spectoral_lipschitz_constant_conv(
        samples=10000,
        norm='l2',
        layers=3,
        width=32,
        strides=1,
        padding='same',
        input_shape=(10,10,1), 
        classes=3,
        kernel_size=3):

    x = Input(input_shape)

    z = x
    for _ in range(layers):
        z = Conv2D(width, kernel_size, strides=strides, padding=padding)(z)
        z = Activation('relu')(z)

    z = Flatten()(z)
    y = Dense(classes)(z)

    f = Model(x, y)

    k = SpectralNormViaPowerMethod(
        f, 100, norm, name='spectral_norm').lipschitz_constant

    X = (np.random.rand(samples, *input_shape) - 0.5) * 2

    delta = np.random.rand(samples, np.prod(input_shape)) - 0.5
    if norm == 'l2':
        delta = delta / np.linalg.norm(delta, axis=1, keepdims=True)
    elif norm == 'linf':
        delta = delta / np.linalg.norm(delta, ord=np.inf, axis=1, keepdims=True)
    else:
        raise ValueError(f'{norm} norm not supported')

    delta = delta.reshape(samples, *input_shape)

    y1 = f.predict(X)
    y2 = f.predict(X + delta)

    empirical_k = np.linalg.norm(y1 - y2, axis=1)

    success_rate = np.mean(empirical_k <= k)

    print('')
    print('-'*80)
    print(f'Sanity-checking convolutional Lipschitz bound with {norm} norm')
    print('-'*80)
    print(
        f'Empirical Lipschitz constant was smaller in {success_rate*100:.1f}% '
        f'of cases')
    print('\nSuccess!' if success_rate == 1. else '\nFailure.')

    if success_rate < 1.:
        for ek_i in empirical_k[empirical_k > k][:10]:
            print(f'>>>> {k} was less than {ek_i}')

    return success_rate == 1.


def _check_l2_norm_of_kernel(
        samples=10,
        width=32,
        strides=1,
        padding='same',
        input_shape=(10,10,3), 
        kernel_size=3):

    x = Input(input_shape)

    z = Conv2D(width, kernel_size, strides=strides, padding=padding)(x)

    f = Model(x, z)

    X = (np.random.rand(samples, *input_shape) - 0.5) * 2

    W_flat = f.predict(
        np.eye(np.prod(input_shape)).reshape(
            np.prod(input_shape), *input_shape)
    ).reshape(np.prod(input_shape), np.prod(f.output_shape[1:]))

    Z1 = f.predict(X)
    Z2 = (X.reshape(samples, -1) @ W_flat).reshape(*Z1.shape)

    flat_weights_correct = np.allclose(Z1, Z2, atol=1e-5)

    N1 = np.linalg.norm(W_flat, axis=1).reshape(f.input_shape[1:])

    N2 = K.get_value(l2_norm_of_kernel(f.layers[-1]))

    norms_match = np.allclose(N1, N2, atol=1e-5)

    success = flat_weights_correct and norms_match

    print('')
    print('-'*80)
    print(f'Checking efficient l2 norm of kernel implementation')
    print('-'*80)
    print('\nSuccess!' if success else '\nFailure.')

    return success


def _check_model_saving(
        norm='l2',
        layers=3,
        width=32,
        strides=1,
        padding='same',
        input_shape=(10,10,1), 
        classes=3,
        kernel_size=3,
        use_operator_norm=True,
        maintain_state=False):

    x = Input(input_shape)

    z = x
    for _ in range(layers):
        z = Conv2D(width, kernel_size, strides=strides, padding=padding)(z)
        z = Activation('relu')(z)

    z = Flatten()(z)
    y = Dense(classes)(z)

    f = Model(x, y)

    model = instrument_with_spectral_norm_margin(
        f, 
        0.5, 
        num_iterations=5, 
        norm=norm, 
        use_operator_norm=use_operator_norm,
        maintain_state=maintain_state)

    model.get_layer('spectral_norm').lipschitz_constant
    model.predict(np.random.rand(4, *input_shape))

    if maintain_state:
        model.get_layer('spectral_norm').refresh_iterates()

    model.save('/tmp/_check_model_saving.h5')
    model.save_weights('/tmp/_check_model_saving_weights.h5')

    model = tf.keras.models.load_model(
        '/tmp/_check_model_saving.h5',
        custom_objects={
            'SpectralNormViaPowerMethod': SpectralNormViaPowerMethod,
            'LipschitzMargin': LipschitzMargin
        })

    model.get_layer('spectral_norm').lipschitz_constant
    model.predict(np.random.rand(4, *input_shape))

    model.load_weights('/tmp/_check_model_saving_weights.h5')

    model.get_layer('spectral_norm').lipschitz_constant
    model.predict(np.random.rand(4, *input_shape))

    return True

    
if __name__ == '__main__':
    import os
    os.environ['TF_CPP_MIN_LOG_LEVEL'] = '3'
    tf.get_logger().setLevel('ERROR')

    from tensorflow.keras.layers import Activation
    from tensorflow.keras.layers import Conv2D
    from tensorflow.keras.layers import Dense
    from tensorflow.keras.layers import Flatten
    from tensorflow.keras.layers import Input

    # Select the GPU and allow memory growth to avoid taking all the RAM.
    gpus = tf.config.experimental.list_physical_devices('GPU')
    tf.config.experimental.set_visible_devices(gpus[2], 'GPU')

    for device in tf.config.experimental.get_visible_devices('GPU'):
        tf.config.experimental.set_memory_growth(device, True)
    
    K.set_image_data_format('channels_last')

    successful_tests = [0]
    total_tests = [0]

    def t(res):
        total_tests[0] += 1
        if res:
            successful_tests[0] += 1

    print('\n\n>> Checking saving and loading of model')
    t(_check_model_saving())
    t(_check_model_saving(use_operator_norm=False))
    t(_check_model_saving(maintain_state=True))
    t(_check_model_saving(use_operator_norm=False, maintain_state=True))


    t(_check_l2_norm_of_kernel(strides=1, padding='valid'))
    t(_check_l2_norm_of_kernel(strides=1, padding='same'))

    # Not yet supported.
    # t(_check_l2_norm_of_kernel(strides=2, padding='valid'))
    # t(_check_l2_norm_of_kernel(strides=2, padding='same'))

    print('\n\n>> Random Models')

    t(_sanity_check_spectoral_lipschitz_constant_dense())
    t(_sanity_check_spectoral_lipschitz_constant_dense(norm='linf'))

    t(_sanity_check_spectoral_lipschitz_constant_conv())
    t(_sanity_check_spectoral_lipschitz_constant_conv(norm='linf'))

    print('\n\n>> Linear Models')

    t(_sanity_check_spectoral_lipschitz_constant_dense(layers=0, classes=1))
    t(_sanity_check_spectoral_lipschitz_constant_dense(
        layers=0, classes=1, norm='linf'))

    print('\n\n>> 1x1 Convolution')

    t(_sanity_check_spectoral_lipschitz_constant_conv(
        layers=1, classes=1, input_shape=(1,1,3)))
    t(_sanity_check_spectoral_lipschitz_constant_conv(
        layers=1, classes=1, input_shape=(1,1,3), norm='linf'))    

    print('\n\n>> Single Hidden Layer')

    t(_sanity_check_spectoral_lipschitz_constant_dense(layers=1))
    t(_sanity_check_spectoral_lipschitz_constant_dense(layers=1, norm='linf'))

    t(_sanity_check_spectoral_lipschitz_constant_conv(layers=1))
    t(_sanity_check_spectoral_lipschitz_constant_conv(layers=1, norm='linf'))

    print('\n\n>> Strided Convolutions')

    t(_sanity_check_spectoral_lipschitz_constant_conv(strides=2))

    # Not currently supported.
    # t(_sanity_check_spectoral_lipschitz_constant_conv(strides=2, norm='linf'))

    print('\n\n>> No Padding')

    t(_sanity_check_spectoral_lipschitz_constant_conv(padding='valid'))
    t(_sanity_check_spectoral_lipschitz_constant_conv(
        padding='valid', norm='linf'))

    print(f'\n{successful_tests[0]} / {total_tests[0]} tests passed\n')
