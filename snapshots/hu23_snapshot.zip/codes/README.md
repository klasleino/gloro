# Scaling in Depth: Unlocking Robustness Certification on ImageNet

## Train the model

Require torch>=1.8.0. Older version may also work.

Run the experiment by:

```
#!/usr/bin/env bash
export MASTER_PORT=$((12000 + $RANDOM % 20000))

OMP_NUM_THREADS=1 python -m torch.distributed.launch --nproc_per_node=8 \
    --master_port $MASTER_PORT train.py --launcher=pytorch \
    ( ... train script args...)
```

For example, our results listed below are trained by:

```
#!/usr/bin/env bash
# CIFAR10
export MASTER_PORT=$((12000 + $RANDOM % 20000))

OMP_NUM_THREADS=1 python -m torch.distributed.launch --nproc_per_node=8 \
    --master_port $MASTER_PORT train.py --launcher=pytorch \
    --config='configs/cifar10.yaml'
```

```
#!/usr/bin/env bash
# CIFAR100
export MASTER_PORT=$((12000 + $RANDOM % 20000))

OMP_NUM_THREADS=1 python -m torch.distributed.launch --nproc_per_node=8 \
    --master_port $MASTER_PORT train.py --launcher=pytorch \
    --config='configs/cifar100.yaml'
```

```
#!/usr/bin/env bash
# Tiny-Imagenet
export MASTER_PORT=$((12000 + $RANDOM % 20000))

OMP_NUM_THREADS=1 python -m torch.distributed.launch --nproc_per_node=8 \
    --master_port $MASTER_PORT train.py --launcher=pytorch \
    --config='configs/tiny_imagenet.yaml'
```